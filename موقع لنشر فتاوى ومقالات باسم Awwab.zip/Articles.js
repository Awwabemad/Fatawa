import React from 'react';
import SearchBar from '../components/common/SearchBar';
import ArticleCard from '../components/common/ArticleCard';
import CategoryList from '../components/common/CategoryList';

const Articles = () => {
  // Mock data for articles
  const allArticles = [
    {
      id: '1',
      title: 'فضل العشر الأواخر من رمضان',
      content: 'تعتبر العشر الأواخر من شهر رمضان المبارك من أفضل أيام العام، حيث تتضاعف فيها الأجور وتُرفع فيها الدرجات. وفيها ليلة القدر التي هي خير من ألف شهر. وقد كان النبي صلى الله عليه وسلم يجتهد فيها ما لا يجتهد في غيرها...',
      author: 'د. محمد الصالح',
      date: '15 رمضان 1445',
      category: 'رمضان'
    },
    {
      id: '2',
      title: 'أثر الصيام في تهذيب النفس',
      content: 'للصيام أثر عظيم في تهذيب النفس وتزكيتها، فهو مدرسة روحية وتربوية يتعلم فيها المسلم الصبر والإرادة والتحكم في الشهوات. ويعتبر الصيام من أهم العبادات التي تساعد على تقوية الإرادة ومجاهدة النفس...',
      author: 'د. أحمد العبد الله',
      date: '10 رمضان 1445',
      category: 'الأخلاق'
    },
    {
      id: '3',
      title: 'الوسطية في الإسلام',
      content: 'تعد الوسطية من أهم خصائص الدين الإسلامي، فهي منهج رباني يقوم على التوازن والاعتدال في كل شؤون الحياة. وقد وصف الله تعالى هذه الأمة بأنها أمة وسط، قال تعالى: "وكذلك جعلناكم أمة وسطا"...',
      author: 'د. عبد الرحمن',
      date: '5 رمضان 1445',
      category: 'العقيدة'
    },
    {
      id: '4',
      title: 'أهمية التربية الإسلامية للأبناء',
      content: 'تعتبر التربية الإسلامية للأبناء من أهم المسؤوليات الملقاة على عاتق الوالدين، فهي الأساس في بناء شخصية الطفل المسلم وتكوين هويته الإسلامية. وتشمل التربية الإسلامية غرس العقيدة الصحيحة وتعليم العبادات وتنمية الأخلاق الحميدة...',
      author: 'د. فاطمة الزهراء',
      date: '1 رمضان 1445',
      category: 'الأسرة'
    },
    {
      id: '5',
      title: 'فقه التعامل مع وسائل التواصل الاجتماعي',
      content: 'أصبحت وسائل التواصل الاجتماعي جزءاً لا يتجزأ من حياتنا اليومية، وهذا يتطلب من المسلم أن يكون على دراية بفقه التعامل معها وفق الضوابط الشرعية. ومن أهم هذه الضوابط: الصدق في النقل، وحفظ الخصوصية، وتجنب نشر الشائعات...',
      author: 'د. خالد المنصور',
      date: '25 شعبان 1445',
      category: 'المعاصرة'
    },
    {
      id: '6',
      title: 'أحكام الزكاة المعاصرة',
      content: 'مع تطور الحياة الاقتصادية ظهرت العديد من المسائل المستجدة في باب الزكاة، مثل زكاة الأسهم والسندات والصناديق الاستثمارية والرواتب والمعاشات. وقد اجتهد العلماء المعاصرون في بيان أحكام هذه المسائل...',
      author: 'د. سعيد الحكيم',
      date: '20 شعبان 1445',
      category: 'المعاملات'
    }
  ];

  return (
    <div className="container mt-5">
      <h1 className="section-title mb-4">المقالات الإسلامية</h1>
      
      <div className="row">
        {/* Main Content Area */}
        <div className="col-12 col-md-8">
          {/* Search Bar */}
          <SearchBar placeholder="ابحث في المقالات..." />
          
          {/* Articles List */}
          <div className="articles-list">
            {allArticles.map(article => (
              <div key={article.id} className="mb-4">
                <ArticleCard article={article} />
              </div>
            ))}
          </div>
          
          {/* Pagination */}
          <div className="pagination-container mt-4 mb-5 d-flex justify-content-center">
            <nav aria-label="صفحات المقالات">
              <ul className="pagination">
                <li className="page-item disabled">
                  <a className="page-link" href="#" aria-label="السابق">
                    <span aria-hidden="true">&laquo;</span>
                  </a>
                </li>
                <li className="page-item active">
                  <a className="page-link" href="#">1</a>
                </li>
                <li className="page-item">
                  <a className="page-link" href="#">2</a>
                </li>
                <li className="page-item">
                  <a className="page-link" href="#">3</a>
                </li>
                <li className="page-item">
                  <a className="page-link" href="#" aria-label="التالي">
                    <span aria-hidden="true">&raquo;</span>
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        
        {/* Sidebar */}
        <div className="col-12 col-md-4">
          <div className="sticky-top" style={{ top: '20px' }}>
            {/* Popular Articles Widget */}
            <div className="card mb-4">
              <h3 className="section-title">الأكثر قراءة</h3>
              <ul className="list-unstyled">
                <li className="mb-2">
                  <a href="/articles/1">فضل العشر الأواخر من رمضان</a>
                </li>
                <li className="mb-2">
                  <a href="/articles/3">الوسطية في الإسلام</a>
                </li>
                <li className="mb-2">
                  <a href="/articles/5">فقه التعامل مع وسائل التواصل الاجتماعي</a>
                </li>
                <li className="mb-2">
                  <a href="/articles/2">أثر الصيام في تهذيب النفس</a>
                </li>
              </ul>
            </div>
            
            {/* Categories Widget */}
            <CategoryList />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Articles;

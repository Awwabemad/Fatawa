const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Favorite = require('../models/Favorite');

// @desc    Get user's favorites
// @route   GET /api/v1/favorites
// @access  Private
exports.getFavorites = asyncHandler(async (req, res, next) => {
  const favorites = await Favorite.find({ userId: req.user.id })
    .populate({
      path: 'itemId',
      select: 'title question answer content scholarId authorId createdAt',
      populate: {
        path: 'scholarId authorId',
        select: 'fullName username'
      }
    });

  res.status(200).json({
    success: true,
    count: favorites.length,
    data: favorites
  });
});

// @desc    Add to favorites
// @route   POST /api/v1/favorites
// @access  Private
exports.addFavorite = asyncHandler(async (req, res, next) => {
  // Add user to req.body
  req.body.userId = req.user.id;

  // Validate item type
  if (!['fatwa', 'article'].includes(req.body.itemType)) {
    return next(
      new ErrorResponse(`نوع العنصر غير صالح: ${req.body.itemType}`, 400)
    );
  }

  // Check if already in favorites
  const existingFavorite = await Favorite.findOne({
    userId: req.user.id,
    itemId: req.body.itemId,
    itemType: req.body.itemType
  });

  if (existingFavorite) {
    return next(
      new ErrorResponse('هذا العنصر موجود بالفعل في المفضلة', 400)
    );
  }

  const favorite = await Favorite.create(req.body);

  res.status(201).json({
    success: true,
    data: favorite
  });
});

// @desc    Remove from favorites
// @route   DELETE /api/v1/favorites/:id
// @access  Private
exports.removeFavorite = asyncHandler(async (req, res, next) => {
  const favorite = await Favorite.findById(req.params.id);

  if (!favorite) {
    return next(
      new ErrorResponse(`لا يوجد عنصر مفضل بهذا المعرف ${req.params.id}`, 404)
    );
  }

  // Make sure user owns the favorite
  if (favorite.userId.toString() !== req.user.id) {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بحذف هذا العنصر المفضل`,
        403
      )
    );
  }

  await favorite.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Check if item is in favorites
// @route   GET /api/v1/favorites/check/:itemType/:itemId
// @access  Private
exports.checkFavorite = asyncHandler(async (req, res, next) => {
  const { itemType, itemId } = req.params;

  // Validate item type
  if (!['fatwa', 'article'].includes(itemType)) {
    return next(
      new ErrorResponse(`نوع العنصر غير صالح: ${itemType}`, 400)
    );
  }

  const favorite = await Favorite.findOne({
    userId: req.user.id,
    itemId,
    itemType
  });

  res.status(200).json({
    success: true,
    isFavorite: !!favorite,
    data: favorite
  });
});

// @desc    Get user's favorites by type
// @route   GET /api/v1/favorites/type/:itemType
// @access  Private
exports.getFavoritesByType = asyncHandler(async (req, res, next) => {
  const { itemType } = req.params;

  // Validate item type
  if (!['fatwa', 'article'].includes(itemType)) {
    return next(
      new ErrorResponse(`نوع العنصر غير صالح: ${itemType}`, 400)
    );
  }

  const favorites = await Favorite.find({
    userId: req.user.id,
    itemType
  }).populate({
    path: 'itemId',
    select: 'title question answer content scholarId authorId createdAt',
    populate: {
      path: 'scholarId authorId',
      select: 'fullName username'
    }
  });

  res.status(200).json({
    success: true,
    count: favorites.length,
    data: favorites
  });
});

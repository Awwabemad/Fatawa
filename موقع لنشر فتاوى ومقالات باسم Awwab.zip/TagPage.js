import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';

const TagPage = () => {
  const { slug } = useParams();
  const [tag, setTag] = useState(null);
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  
  // Mock data for demonstration
  useEffect(() => {
    setLoading(true);
    
    // In a real application, this would fetch data from the backend API
    setTimeout(() => {
      // Mock tags data
      const mockTags = [
        { _id: '1', name: 'رمضان', slug: 'ramadan', description: 'محتوى متعلق بشهر رمضان المبارك وأحكامه وفضائله' },
        { _id: '2', name: 'الصلاة', slug: 'prayer', description: 'محتوى متعلق بالصلاة وأحكامها وفضائلها' },
        { _id: '3', name: 'الزكاة', slug: 'zakat', description: 'محتوى متعلق بالزكاة وأحكامها ومصارفها' },
        { _id: '4', name: 'الحج', slug: 'hajj', description: 'محتوى متعلق بالحج والعمرة وأحكامهما' },
        { _id: '5', name: 'الصيام', slug: 'fasting', description: 'محتوى متعلق بالصيام وأحكامه وفضائله' }
      ];
      
      // Find the tag by slug
      const foundTag = mockTags.find(t => t.slug === slug);
      setTag(foundTag);
      
      if (foundTag) {
        // Mock content data
        const mockContent = [
          {
            _id: '1',
            title: 'حكم صيام الست من شوال',
            type: 'fatwa',
            excerpt: 'صيام ستة أيام من شوال بعد رمضان سنة مستحبة، وليست واجبة، ويجوز أن تكون متتابعة أو متفرقة...',
            date: '2025-03-20T14:45:00',
            category: { _id: '2', name: 'العبادات', slug: 'worship' },
            tags: [
              { _id: '1', name: 'رمضان', slug: 'ramadan' },
              { _id: '5', name: 'الصيام', slug: 'fasting' }
            ],
            url: '/fatwas/1'
          },
          {
            _id: '3',
            title: 'فضل العشر الأواخر من رمضان',
            type: 'article',
            excerpt: 'العشر الأواخر من رمضان هي أفضل أيام الشهر الكريم، وفيها ليلة القدر التي هي خير من ألف شهر...',
            date: '2025-03-20T14:45:00',
            category: { _id: '2', name: 'العبادات', slug: 'worship' },
            tags: [
              { _id: '1', name: 'رمضان', slug: 'ramadan' },
              { _id: '5', name: 'الصيام', slug: 'fasting' }
            ],
            url: '/articles/1'
          },
          {
            _id: '4',
            title: 'أثر الصيام في تهذيب النفس',
            type: 'article',
            excerpt: 'الصيام من أعظم العبادات التي تهذب النفس وتزكيها، وتقوي الإرادة وتعلم الصبر...',
            date: '2025-03-18T11:30:00',
            category: { _id: '5', name: 'الأخلاق', slug: 'ethics' },
            tags: [
              { _id: '1', name: 'رمضان', slug: 'ramadan' },
              { _id: '5', name: 'الصيام', slug: 'fasting' }
            ],
            url: '/articles/2'
          },
          {
            _id: '5',
            title: 'حكم صلاة التراويح في المنزل',
            type: 'fatwa',
            excerpt: 'صلاة التراويح سنة مؤكدة، والأفضل أداؤها في المسجد جماعة، ولكن يجوز أداؤها في المنزل...',
            date: '2025-03-28T10:15:00',
            category: { _id: '2', name: 'العبادات', slug: 'worship' },
            tags: [
              { _id: '1', name: 'رمضان', slug: 'ramadan' },
              { _id: '2', name: 'الصلاة', slug: 'prayer' }
            ],
            url: '/fatwas/4'
          },
          {
            _id: '8',
            title: 'فضل قيام رمضان',
            type: 'article',
            excerpt: 'قيام رمضان من أفضل العبادات في شهر رمضان المبارك، ومن قام رمضان إيماناً واحتساباً غفر له ما تقدم من ذنبه...',
            date: '2025-03-05T10:15:00',
            category: { _id: '2', name: 'العبادات', slug: 'worship' },
            tags: [
              { _id: '1', name: 'رمضان', slug: 'ramadan' },
              { _id: '2', name: 'الصلاة', slug: 'prayer' }
            ],
            url: '/articles/4'
          }
        ];
        
        // Filter content by tag
        const filteredContent = mockContent.filter(item => 
          item.tags.some(t => t.slug === slug)
        );
        setContent(filteredContent);
        setTotalPages(Math.ceil(filteredContent.length / 5));
      }
      
      setLoading(false);
    }, 1000);
  }, [slug]);
  
  // Format date to Arabic format
  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Filter content by type
  const filteredContent = activeTab === 'all' 
    ? content 
    : content.filter(item => item.type === activeTab);
  
  // Paginate content
  const itemsPerPage = 5;
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedContent = filteredContent.slice(startIndex, startIndex + itemsPerPage);
  
  return (
    <div className="container mt-5">
      {loading ? (
        <div className="text-center my-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">جاري التحميل...</span>
          </div>
          <p className="mt-2">جاري تحميل المحتوى...</p>
        </div>
      ) : tag ? (
        <>
          <div className="row mb-4">
            <div className="col-12">
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item"><Link to="/">الرئيسية</Link></li>
                  <li className="breadcrumb-item"><Link to="/tags">الوسوم</Link></li>
                  <li className="breadcrumb-item active" aria-current="page">{tag.name}</li>
                </ol>
              </nav>
              
              <div className="tag-header mb-4">
                <h1 className="mb-3">
                  <i className="fas fa-tag me-2 text-primary"></i>
                  {tag.name}
                </h1>
                <p className="lead">{tag.description}</p>
              </div>
              
              <ul className="nav nav-tabs mb-4">
                <li className="nav-item">
                  <button 
                    className={`nav-link ${activeTab === 'all' ? 'active' : ''}`}
                    onClick={() => setActiveTab('all')}
                  >
                    الكل ({content.length})
                  </button>
                </li>
                <li className="nav-item">
                  <button 
                    className={`nav-link ${activeTab === 'fatwa' ? 'active' : ''}`}
                    onClick={() => setActiveTab('fatwa')}
                  >
                    الفتاوى ({content.filter(item => item.type === 'fatwa').length})
                  </button>
                </li>
                <li className="nav-item">
                  <button 
                    className={`nav-link ${activeTab === 'article' ? 'active' : ''}`}
                    onClick={() => setActiveTab('article')}
                  >
                    المقالات ({content.filter(item => item.type === 'article').length})
                  </button>
                </li>
              </ul>
              
              {filteredContent.length > 0 ? (
                <>
                  <div className="list-group">
                    {paginatedContent.map(item => (
                      <div key={`${item.type}-${item._id}`} className="list-group-item list-group-item-action">
                        <div className="d-flex w-100 justify-content-between align-items-center mb-2">
                          <h5 className="mb-0">
                            <Link to={item.url} className="text-decoration-none">
                              {item.title}
                            </Link>
                          </h5>
                          <span className={`badge bg-${item.type === 'fatwa' ? 'primary' : 'success'}`}>
                            {item.type === 'fatwa' ? 'فتوى' : 'مقال'}
                          </span>
                        </div>
                        <p className="mb-2">{item.excerpt}</p>
                        <div className="d-flex justify-content-between align-items-center">
                          <Link to={`/categories/${item.category.slug}`} className="badge bg-secondary text-decoration-none">
                            {item.category.name}
                          </Link>
                          <small className="text-muted">{formatDate(item.date)}</small>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {totalPages > 1 && (
                    <nav aria-label="Page navigation" className="mt-4">
                      <ul className="pagination justify-content-center">
                        <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                          <button
                            className="page-link"
                            onClick={() => setCurrentPage(currentPage - 1)}
                            disabled={currentPage === 1}
                          >
                            السابق
                          </button>
                        </li>
                        
                        {[...Array(totalPages)].map((_, index) => (
                          <li
                            key={index}
                            className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}
                          >
                            <button
                              className="page-link"
                              onClick={() => setCurrentPage(index + 1)}
                            >
                              {index + 1}
                            </button>
                          </li>
                        ))}
                        
                        <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                          <button
                            className="page-link"
                            onClick={() => setCurrentPage(currentPage + 1)}
                            disabled={currentPage === totalPages}
                          >
                            التالي
                          </button>
                        </li>
                      </ul>
                    </nav>
                  )}
                </>
              ) : (
                <div className="alert alert-info text-center" role="alert">
                  <i className="fas fa-info-circle me-2"></i>
                  لا يوجد محتوى مرتبط بهذا الوسم حالياً
                </div>
              )}
            </div>
          </div>
        </>
      ) : (
        <div className="alert alert-warning text-center" role="alert">
          <i className="fas fa-exclamation-triangle me-2"></i>
          الوسم غير موجود
        </div>
      )}
    </div>
  );
};

export default TagPage;

import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => {
  return (
    <div className="container mt-5 text-center">
      <div className="row">
        <div className="col-md-8 mx-auto">
          <h1 className="display-1 text-primary">404</h1>
          <h2 className="mb-4">الصفحة غير موجودة</h2>
          <p className="lead mb-5">
            عذراً، الصفحة التي تبحث عنها غير موجودة أو تم نقلها أو حذفها.
          </p>
          <Link to="/" className="btn btn-primary btn-lg">
            العودة إلى الصفحة الرئيسية
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;

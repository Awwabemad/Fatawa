const mongoose = require('mongoose');

const TagSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'الرجاء إدخال اسم الوسم'],
    unique: true,
    trim: true,
    maxlength: [50, 'اسم الوسم لا يمكن أن يتجاوز 50 حرفاً']
  },
  slug: {
    type: String,
    unique: true,
    trim: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create slug from name before saving
TagSchema.pre('save', function(next) {
  // Create slug from name
  this.slug = this.name
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^\u0621-\u064A\u0660-\u0669a-z0-9-]/g, '');
  
  next();
});

module.exports = mongoose.model('Tag', TagSchema);

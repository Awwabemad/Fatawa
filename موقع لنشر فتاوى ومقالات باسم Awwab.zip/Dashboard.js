import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    fatwas: {
      total: 156,
      published: 124,
      draft: 28,
      archived: 4
    },
    articles: {
      total: 87,
      published: 72,
      draft: 12,
      archived: 3
    },
    users: {
      total: 1250,
      scholars: 8,
      admins: 3,
      regular: 1239
    },
    fatwaRequests: {
      total: 42,
      pending: 15,
      answered: 24,
      rejected: 3
    },
    comments: {
      total: 328,
      pending: 18,
      approved: 295,
      rejected: 15
    }
  });

  const [recentActivities, setRecentActivities] = useState([
    {
      id: 1,
      type: 'fatwa',
      action: 'publish',
      title: 'حكم صيام الست من شوال',
      user: 'الشيخ أحمد',
      date: '2025-04-05T10:30:00'
    },
    {
      id: 2,
      type: 'article',
      action: 'create',
      title: 'فضل العشر الأواخر من رمضان',
      user: 'د. محمد',
      date: '2025-04-05T09:15:00'
    },
    {
      id: 3,
      type: 'fatwaRequest',
      action: 'answer',
      title: 'حكم زكاة الأسهم',
      user: 'الشيخ عبدالله',
      date: '2025-04-04T16:45:00'
    },
    {
      id: 4,
      type: 'comment',
      action: 'approve',
      title: 'تعليق على فتوى صلاة المسافر',
      user: 'المشرف خالد',
      date: '2025-04-04T14:20:00'
    },
    {
      id: 5,
      type: 'user',
      action: 'register',
      title: 'تسجيل مستخدم جديد',
      user: 'أحمد محمد',
      date: '2025-04-04T11:10:00'
    }
  ]);

  // Format date to Arabic format
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get icon for activity type
  const getActivityIcon = (type) => {
    switch (type) {
      case 'fatwa':
        return 'fa-scroll';
      case 'article':
        return 'fa-newspaper';
      case 'fatwaRequest':
        return 'fa-question-circle';
      case 'comment':
        return 'fa-comment';
      case 'user':
        return 'fa-user';
      default:
        return 'fa-bell';
    }
  };

  // Get color for activity type
  const getActivityColor = (type) => {
    switch (type) {
      case 'fatwa':
        return 'primary';
      case 'article':
        return 'success';
      case 'fatwaRequest':
        return 'warning';
      case 'comment':
        return 'info';
      case 'user':
        return 'secondary';
      default:
        return 'dark';
    }
  };

  return (
    <div className="container-fluid mt-4">
      <h1 className="mb-4">لوحة التحكم</h1>
      
      {/* Stats Cards */}
      <div className="row">
        <div className="col-md-4 mb-4">
          <div className="card border-primary h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <h5 className="card-title">الفتاوى</h5>
                  <h2 className="display-4">{stats.fatwas.total}</h2>
                </div>
                <i className="fas fa-scroll fa-3x text-primary opacity-50"></i>
              </div>
              <div className="mt-3">
                <span className="badge bg-success me-2">منشور: {stats.fatwas.published}</span>
                <span className="badge bg-warning me-2">مسودة: {stats.fatwas.draft}</span>
                <span className="badge bg-secondary">مؤرشف: {stats.fatwas.archived}</span>
              </div>
            </div>
            <div className="card-footer bg-transparent border-primary">
              <Link to="/admin/fatwas" className="btn btn-sm btn-outline-primary">
                إدارة الفتاوى
              </Link>
            </div>
          </div>
        </div>
        
        <div className="col-md-4 mb-4">
          <div className="card border-success h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <h5 className="card-title">المقالات</h5>
                  <h2 className="display-4">{stats.articles.total}</h2>
                </div>
                <i className="fas fa-newspaper fa-3x text-success opacity-50"></i>
              </div>
              <div className="mt-3">
                <span className="badge bg-success me-2">منشور: {stats.articles.published}</span>
                <span className="badge bg-warning me-2">مسودة: {stats.articles.draft}</span>
                <span className="badge bg-secondary">مؤرشف: {stats.articles.archived}</span>
              </div>
            </div>
            <div className="card-footer bg-transparent border-success">
              <Link to="/admin/articles" className="btn btn-sm btn-outline-success">
                إدارة المقالات
              </Link>
            </div>
          </div>
        </div>
        
        <div className="col-md-4 mb-4">
          <div className="card border-warning h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <h5 className="card-title">طلبات الفتاوى</h5>
                  <h2 className="display-4">{stats.fatwaRequests.total}</h2>
                </div>
                <i className="fas fa-question-circle fa-3x text-warning opacity-50"></i>
              </div>
              <div className="mt-3">
                <span className="badge bg-warning me-2">قيد الانتظار: {stats.fatwaRequests.pending}</span>
                <span className="badge bg-success me-2">تمت الإجابة: {stats.fatwaRequests.answered}</span>
                <span className="badge bg-danger">مرفوض: {stats.fatwaRequests.rejected}</span>
              </div>
            </div>
            <div className="card-footer bg-transparent border-warning">
              <Link to="/admin/fatwa-requests" className="btn btn-sm btn-outline-warning">
                إدارة طلبات الفتاوى
              </Link>
            </div>
          </div>
        </div>
      </div>
      
      <div className="row">
        <div className="col-md-6 mb-4">
          <div className="card border-info h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <h5 className="card-title">التعليقات</h5>
                  <h2 className="display-4">{stats.comments.total}</h2>
                </div>
                <i className="fas fa-comments fa-3x text-info opacity-50"></i>
              </div>
              <div className="mt-3">
                <span className="badge bg-warning me-2">قيد المراجعة: {stats.comments.pending}</span>
                <span className="badge bg-success me-2">معتمد: {stats.comments.approved}</span>
                <span className="badge bg-danger">مرفوض: {stats.comments.rejected}</span>
              </div>
            </div>
            <div className="card-footer bg-transparent border-info">
              <Link to="/admin/comments" className="btn btn-sm btn-outline-info">
                إدارة التعليقات
              </Link>
            </div>
          </div>
        </div>
        
        <div className="col-md-6 mb-4">
          <div className="card border-secondary h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <h5 className="card-title">المستخدمون</h5>
                  <h2 className="display-4">{stats.users.total}</h2>
                </div>
                <i className="fas fa-users fa-3x text-secondary opacity-50"></i>
              </div>
              <div className="mt-3">
                <span className="badge bg-primary me-2">علماء: {stats.users.scholars}</span>
                <span className="badge bg-danger me-2">مشرفون: {stats.users.admins}</span>
                <span className="badge bg-secondary">مستخدمون عاديون: {stats.users.regular}</span>
              </div>
            </div>
            <div className="card-footer bg-transparent border-secondary">
              <Link to="/admin/users" className="btn btn-sm btn-outline-secondary">
                إدارة المستخدمين
              </Link>
            </div>
          </div>
        </div>
      </div>
      
      {/* Recent Activities */}
      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-header bg-white">
              <h5 className="mb-0">آخر النشاطات</h5>
            </div>
            <div className="card-body">
              <div className="list-group">
                {recentActivities.map(activity => (
                  <div key={activity.id} className="list-group-item list-group-item-action">
                    <div className="d-flex w-100 justify-content-between align-items-center">
                      <div>
                        <i className={`fas ${getActivityIcon(activity.type)} text-${getActivityColor(activity.type)} me-2`}></i>
                        <span className="fw-bold">{activity.title}</span>
                        <span className="text-muted me-2">بواسطة {activity.user}</span>
                      </div>
                      <small className="text-muted">{formatDate(activity.date)}</small>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="card-footer bg-white">
              <Link to="/admin/activities" className="btn btn-sm btn-outline-dark">
                عرض جميع النشاطات
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;

import React, { useState } from 'react';
import SearchBar from '../components/common/SearchBar';
import FatwaCard from '../components/common/FatwaCard';
import CategoryList from '../components/common/CategoryList';

const Fatwas = () => {
  // Mock data for fatwas
  const allFatwas = [
    {
      id: '1',
      title: 'حكم صلاة التراويح في المنزل',
      question: 'ما حكم صلاة التراويح في المنزل بدلاً من المسجد؟ وهل يجوز أن أصليها منفرداً؟',
      scholar: 'الشيخ عبد الله',
      date: '15 رمضان 1445',
      category: 'العبادات'
    },
    {
      id: '2',
      title: 'زكاة المال المستثمر في الأسهم',
      question: 'كيف أحسب زكاة المال المستثمر في الأسهم والصناديق الاستثمارية؟',
      scholar: 'الشيخ محمد',
      date: '10 رمضان 1445',
      category: 'المعاملات'
    },
    {
      id: '3',
      title: 'حكم استخدام وسائل التواصل الاجتماعي',
      question: 'ما حكم استخدام وسائل التواصل الاجتماعي للدعوة إلى الله؟ وما ضوابط ذلك؟',
      scholar: 'الشيخ أحمد',
      date: '5 رمضان 1445',
      category: 'الدعوة'
    },
    {
      id: '4',
      title: 'حكم التبرع بالأعضاء بعد الوفاة',
      question: 'ما حكم التبرع بالأعضاء بعد الوفاة؟ وهل يجوز للمسلم أن يوصي بذلك؟',
      scholar: 'الشيخ محمد',
      date: '1 رمضان 1445',
      category: 'الطب'
    },
    {
      id: '5',
      title: 'حكم الاحتفال بالمولد النبوي',
      question: 'ما حكم الاحتفال بالمولد النبوي؟ وهل هناك دليل على مشروعيته؟',
      scholar: 'الشيخ عبد الله',
      date: '25 شعبان 1445',
      category: 'العقيدة'
    },
    {
      id: '6',
      title: 'حكم التعامل مع البنوك التقليدية',
      question: 'ما حكم التعامل مع البنوك التقليدية في بلد لا توجد فيه بنوك إسلامية؟',
      scholar: 'الشيخ أحمد',
      date: '20 شعبان 1445',
      category: 'المعاملات'
    }
  ];

  // State for active category filter
  const [activeCategory, setActiveCategory] = useState('الكل');

  // Filter fatwas by category
  const filteredFatwas = activeCategory === 'الكل' 
    ? allFatwas 
    : allFatwas.filter(fatwa => fatwa.category === activeCategory);

  // Categories for filter
  const categories = [
    { id: 'all', name: 'الكل' },
    { id: '1', name: 'العبادات' },
    { id: '2', name: 'المعاملات' },
    { id: '3', name: 'العقيدة' },
    { id: '4', name: 'الدعوة' },
    { id: '5', name: 'الطب' }
  ];

  return (
    <div className="container mt-5">
      <h1 className="section-title mb-4">الفتاوى الشرعية</h1>
      
      <div className="row">
        {/* Main Content Area */}
        <div className="col-12 col-md-8">
          {/* Search Bar */}
          <SearchBar placeholder="ابحث في الفتاوى..." />
          
          {/* Category Filter */}
          <div className="category-filter mb-4">
            <div className="d-flex flex-wrap">
              {categories.map(category => (
                <button
                  key={category.id}
                  className={`btn ${activeCategory === category.name ? 'btn-primary' : 'btn-outline-primary'} ml-2 mb-2`}
                  onClick={() => setActiveCategory(category.name)}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
          
          {/* Fatwas List */}
          <div className="fatwas-list">
            {filteredFatwas.length > 0 ? (
              filteredFatwas.map(fatwa => (
                <div key={fatwa.id} className="mb-4">
                  <FatwaCard fatwa={fatwa} />
                </div>
              ))
            ) : (
              <div className="alert alert-info">
                لا توجد فتاوى في هذا التصنيف حالياً.
              </div>
            )}
          </div>
          
          {/* Pagination */}
          <div className="pagination-container mt-4 mb-5 d-flex justify-content-center">
            <nav aria-label="صفحات الفتاوى">
              <ul className="pagination">
                <li className="page-item disabled">
                  <a className="page-link" href="#" aria-label="السابق">
                    <span aria-hidden="true">&laquo;</span>
                  </a>
                </li>
                <li className="page-item active">
                  <a className="page-link" href="#">1</a>
                </li>
                <li className="page-item">
                  <a className="page-link" href="#">2</a>
                </li>
                <li className="page-item">
                  <a className="page-link" href="#">3</a>
                </li>
                <li className="page-item">
                  <a className="page-link" href="#" aria-label="التالي">
                    <span aria-hidden="true">&raquo;</span>
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        
        {/* Sidebar */}
        <div className="col-12 col-md-4">
          <div className="sticky-top" style={{ top: '20px' }}>
            {/* Ask Fatwa Widget */}
            <div className="card mb-4">
              <h3 className="section-title">اسأل سؤالك</h3>
              <p>
                هل لديك سؤال شرعي؟ يمكنك إرسال سؤالك وسيتم الإجابة عليه من قبل علمائنا المختصين.
              </p>
              <div className="text-center mt-3">
                <a href="/ask-fatwa" className="btn btn-primary">اسأل الآن</a>
              </div>
            </div>
            
            {/* Categories Widget */}
            <CategoryList />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Fatwas;

import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Search = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  
  const handleSearch = (e) => {
    e.preventDefault();
    
    if (!searchTerm.trim()) return;
    
    setLoading(true);
    setSearched(true);
    
    // In a real application, this would call the backend API
    setTimeout(() => {
      // Mock search results
      const mockResults = [
        {
          _id: '1',
          title: 'حكم صيام الست من شوال',
          type: 'fatwa',
          excerpt: 'صيام ستة أيام من شوال بعد رمضان سنة مستحبة، وليست واجبة، ويجوز أن تكون متتابعة أو متفرقة...',
          date: '2025-03-20T14:45:00',
          url: '/fatwas/1'
        },
        {
          _id: '3',
          title: 'فضل العشر الأواخر من رمضان',
          type: 'article',
          excerpt: 'العشر الأواخر من رمضان هي أفضل أيام الشهر الكريم، وفيها ليلة القدر التي هي خير من ألف شهر...',
          date: '2025-03-20T14:45:00',
          url: '/articles/1'
        },
        {
          _id: '5',
          title: 'حكم صلاة التراويح في المنزل',
          type: 'fatwa',
          excerpt: 'صلاة التراويح سنة مؤكدة، والأفضل أداؤها في المسجد جماعة، ولكن يجوز أداؤها في المنزل...',
          date: '2025-03-28T10:15:00',
          url: '/fatwas/4'
        }
      ];
      
      // Filter results based on search term
      const filteredResults = mockResults.filter(
        result => 
          result.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
          result.excerpt.toLowerCase().includes(searchTerm.toLowerCase())
      );
      
      setSearchResults(filteredResults);
      setLoading(false);
    }, 1000);
  };
  
  // Format date to Arabic format
  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-12">
          <h1 className="mb-4">البحث</h1>
          
          <div className="card mb-4">
            <div className="card-body">
              <form onSubmit={handleSearch}>
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="ابحث في الفتاوى والمقالات..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    required
                  />
                  <button className="btn btn-primary" type="submit">
                    <i className="fas fa-search me-2"></i>
                    بحث
                  </button>
                </div>
              </form>
              <div className="mt-2 text-end">
                <Link to="/advanced-search" className="text-decoration-none">
                  البحث المتقدم <i className="fas fa-arrow-left"></i>
                </Link>
              </div>
            </div>
          </div>
          
          {loading ? (
            <div className="text-center my-5">
              <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">جاري البحث...</span>
              </div>
              <p className="mt-2">جاري البحث...</p>
            </div>
          ) : (
            searched && (
              <div className="search-results">
                <h2 className="mb-3">نتائج البحث ({searchResults.length})</h2>
                
                {searchResults.length > 0 ? (
                  <div className="list-group">
                    {searchResults.map(result => (
                      <div key={`${result.type}-${result._id}`} className="list-group-item list-group-item-action">
                        <div className="d-flex w-100 justify-content-between align-items-center mb-2">
                          <h5 className="mb-0">
                            <Link to={result.url} className="text-decoration-none">
                              {result.title}
                            </Link>
                          </h5>
                          <span className={`badge bg-${result.type === 'fatwa' ? 'primary' : 'success'}`}>
                            {result.type === 'fatwa' ? 'فتوى' : 'مقال'}
                          </span>
                        </div>
                        <p className="mb-2">{result.excerpt}</p>
                        <small className="text-muted">{formatDate(result.date)}</small>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="alert alert-info text-center" role="alert">
                    <i className="fas fa-info-circle me-2"></i>
                    لم يتم العثور على نتائج مطابقة لكلمة البحث "{searchTerm}"
                  </div>
                )}
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default Search;

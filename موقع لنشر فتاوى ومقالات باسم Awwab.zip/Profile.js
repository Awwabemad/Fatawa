import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Profile = () => {
  const [user, setUser] = useState({
    fullName: 'محمد أحمد',
    email: 'mohammed@example.com',
    joinDate: '10 رجب 1444',
    bio: 'مهتم بالعلوم الشرعية والفقه الإسلامي',
    avatar: 'https://via.placeholder.com/150'
  });

  const [savedFatwas, setSavedFatwas] = useState([
    { id: 1, title: 'حكم صلاة التراويح في المنزل' },
    { id: 2, title: 'زكاة المال المستثمر في الأسهم' },
    { id: 3, title: 'حكم استخدام وسائل التواصل الاجتماعي' }
  ]);

  const [savedArticles, setSavedArticles] = useState([
    { id: 1, title: 'فضل العشر الأواخر من رمضان' },
    { id: 2, title: 'أثر الصيام في تهذيب النفس' }
  ]);

  const [askedQuestions, setAskedQuestions] = useState([
    { 
      id: 1, 
      question: 'ما حكم الجمع بين صلاتي الظهر والعصر للمسافر؟', 
      status: 'تمت الإجابة',
      date: '15 شعبان 1445'
    },
    { 
      id: 2, 
      question: 'هل يجوز قراءة القرآن من الهاتف المحمول في الصلاة؟', 
      status: 'قيد المراجعة',
      date: '20 شعبان 1445'
    }
  ]);

  return (
    <div className="container mt-5">
      <div className="row">
        {/* Profile Sidebar */}
        <div className="col-md-4 mb-4">
          <div className="card text-center">
            <div className="card-body">
              <img 
                src={user.avatar} 
                alt={user.fullName} 
                className="rounded-circle mb-3" 
                width="150" 
                height="150" 
              />
              <h3>{user.fullName}</h3>
              <p className="text-muted">
                عضو منذ {user.joinDate}
              </p>
              <p>{user.bio}</p>
              <Link to="/edit-profile" className="btn btn-primary">
                تعديل الملف الشخصي
              </Link>
            </div>
          </div>
        </div>
        
        {/* Profile Content */}
        <div className="col-md-8">
          {/* Profile Tabs */}
          <ul className="nav nav-tabs mb-4" id="profileTabs" role="tablist">
            <li className="nav-item" role="presentation">
              <button 
                className="nav-link active" 
                id="fatwas-tab" 
                data-bs-toggle="tab" 
                data-bs-target="#fatwas" 
                type="button" 
                role="tab" 
                aria-controls="fatwas" 
                aria-selected="true"
              >
                الفتاوى المحفوظة
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button 
                className="nav-link" 
                id="articles-tab" 
                data-bs-toggle="tab" 
                data-bs-target="#articles" 
                type="button" 
                role="tab" 
                aria-controls="articles" 
                aria-selected="false"
              >
                المقالات المحفوظة
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button 
                className="nav-link" 
                id="questions-tab" 
                data-bs-toggle="tab" 
                data-bs-target="#questions" 
                type="button" 
                role="tab" 
                aria-controls="questions" 
                aria-selected="false"
              >
                أسئلتي
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button 
                className="nav-link" 
                id="settings-tab" 
                data-bs-toggle="tab" 
                data-bs-target="#settings" 
                type="button" 
                role="tab" 
                aria-controls="settings" 
                aria-selected="false"
              >
                إعدادات الحساب
              </button>
            </li>
          </ul>
          
          {/* Tab Content */}
          <div className="tab-content" id="profileTabsContent">
            {/* Saved Fatwas */}
            <div 
              className="tab-pane fade show active" 
              id="fatwas" 
              role="tabpanel" 
              aria-labelledby="fatwas-tab"
            >
              <h3 className="mb-3">الفتاوى المحفوظة</h3>
              {savedFatwas.length > 0 ? (
                <div className="list-group">
                  {savedFatwas.map(fatwa => (
                    <Link 
                      key={fatwa.id} 
                      to={`/fatwas/${fatwa.id}`} 
                      className="list-group-item list-group-item-action"
                    >
                      <div className="d-flex w-100 justify-content-between">
                        <h5 className="mb-1">{fatwa.title}</h5>
                        <button className="btn btn-sm btn-outline-danger">
                          <i className="fas fa-trash-alt"></i>
                        </button>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <p>لا توجد فتاوى محفوظة.</p>
              )}
            </div>
            
            {/* Saved Articles */}
            <div 
              className="tab-pane fade" 
              id="articles" 
              role="tabpanel" 
              aria-labelledby="articles-tab"
            >
              <h3 className="mb-3">المقالات المحفوظة</h3>
              {savedArticles.length > 0 ? (
                <div className="list-group">
                  {savedArticles.map(article => (
                    <Link 
                      key={article.id} 
                      to={`/articles/${article.id}`} 
                      className="list-group-item list-group-item-action"
                    >
                      <div className="d-flex w-100 justify-content-between">
                        <h5 className="mb-1">{article.title}</h5>
                        <button className="btn btn-sm btn-outline-danger">
                          <i className="fas fa-trash-alt"></i>
                        </button>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <p>لا توجد مقالات محفوظة.</p>
              )}
            </div>
            
            {/* My Questions */}
            <div 
              className="tab-pane fade" 
              id="questions" 
              role="tabpanel" 
              aria-labelledby="questions-tab"
            >
              <h3 className="mb-3">أسئلتي</h3>
              {askedQuestions.length > 0 ? (
                <div className="list-group">
                  {askedQuestions.map(question => (
                    <div 
                      key={question.id} 
                      className="list-group-item"
                    >
                      <div className="d-flex w-100 justify-content-between">
                        <h5 className="mb-1">{question.question}</h5>
                        <small className={`badge ${question.status === 'تمت الإجابة' ? 'bg-success' : 'bg-warning'}`}>
                          {question.status}
                        </small>
                      </div>
                      <p className="mb-1">تاريخ السؤال: {question.date}</p>
                      {question.status === 'تمت الإجابة' && (
                        <Link to={`/fatwas/${question.id}`} className="btn btn-sm btn-primary mt-2">
                          عرض الإجابة
                        </Link>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p>لم تقم بطرح أي أسئلة بعد.</p>
              )}
              <div className="mt-3">
                <Link to="/ask-fatwa" className="btn btn-primary">
                  اسأل سؤالاً جديداً
                </Link>
              </div>
            </div>
            
            {/* Account Settings */}
            <div 
              className="tab-pane fade" 
              id="settings" 
              role="tabpanel" 
              aria-labelledby="settings-tab"
            >
              <h3 className="mb-3">إعدادات الحساب</h3>
              <div className="card">
                <div className="card-body">
                  <form>
                    <div className="form-group mb-3">
                      <label htmlFor="changeEmail">تغيير البريد الإلكتروني</label>
                      <input
                        type="email"
                        className="form-control"
                        id="changeEmail"
                        value={user.email}
                      />
                    </div>
                    
                    <div className="form-group mb-3">
                      <label htmlFor="currentPassword">كلمة المرور الحالية</label>
                      <input
                        type="password"
                        className="form-control"
                        id="currentPassword"
                      />
                    </div>
                    
                    <div className="form-group mb-3">
                      <label htmlFor="newPassword">كلمة المرور الجديدة</label>
                      <input
                        type="password"
                        className="form-control"
                        id="newPassword"
                      />
                    </div>
                    
                    <div className="form-group mb-3">
                      <label htmlFor="confirmNewPassword">تأكيد كلمة المرور الجديدة</label>
                      <input
                        type="password"
                        className="form-control"
                        id="confirmNewPassword"
                      />
                    </div>
                    
                    <button type="submit" className="btn btn-primary">
                      حفظ التغييرات
                    </button>
                  </form>
                </div>
              </div>
              
              <div className="mt-4">
                <h4 className="text-danger">حذف الحساب</h4>
                <p>
                  تحذير: حذف حسابك سيؤدي إلى فقدان جميع بياناتك ولا يمكن التراجع عن هذه العملية.
                </p>
                <button className="btn btn-danger">
                  حذف الحساب
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;

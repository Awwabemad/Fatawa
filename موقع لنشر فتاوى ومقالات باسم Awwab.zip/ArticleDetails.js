import React from 'react';
import { useParams, Link } from 'react-router-dom';
import CategoryList from '../components/common/CategoryList';

const ArticleDetails = () => {
  const { id } = useParams();
  
  // Mock article data (in a real app, this would be fetched from an API)
  const article = {
    id: id,
    title: 'فضل العشر الأواخر من رمضان',
    content: `# فضل العشر الأواخر من رمضان

بسم الله الرحمن الرحيم، والحمد لله رب العالمين، والصلاة والسلام على أشرف الأنبياء والمرسلين، نبينا محمد وعلى آله وصحبه أجمعين.

## فضل العشر الأواخر من رمضان

تعتبر العشر الأواخر من شهر رمضان المبارك من أفضل أيام العام، حيث تتضاعف فيها الأجور وتُرفع فيها الدرجات. وفيها ليلة القدر التي هي خير من ألف شهر. وقد كان النبي صلى الله عليه وسلم يجتهد فيها ما لا يجتهد في غيرها.

### اجتهاد النبي صلى الله عليه وسلم في العشر الأواخر

عن عائشة رضي الله عنها قالت: "كان رسول الله صلى الله عليه وسلم إذا دخل العشر شد مئزره، وأحيا ليله، وأيقظ أهله" رواه البخاري ومسلم.

وفي رواية لمسلم: "كان رسول الله صلى الله عليه وسلم يجتهد في العشر الأواخر ما لا يجتهد في غيره".

وهذا يدل على فضل هذه الأيام وعظم أجرها عند الله تعالى، وأنها فرصة عظيمة للتقرب إلى الله تعالى بأنواع العبادات والطاعات.

### ليلة القدر في العشر الأواخر

من أعظم فضائل العشر الأواخر من رمضان أن فيها ليلة القدر، التي قال الله تعالى فيها: "ليلة القدر خير من ألف شهر" [القدر: 3].

وقد أخبر النبي صلى الله عليه وسلم أن ليلة القدر في العشر الأواخر من رمضان، فقال: "تحروا ليلة القدر في العشر الأواخر من رمضان" رواه البخاري ومسلم.

وقال أيضاً: "التمسوها في العشر الأواخر، في كل وتر" رواه البخاري.

وأرجح الأقوال في تحديدها أنها ليلة السابع والعشرين، لما روي عن أبي بن كعب رضي الله عنه أنه قال: "والله إني لأعلم أي ليلة هي، هي الليلة التي أمرنا بها رسول الله صلى الله عليه وسلم بقيامها، هي ليلة سبع وعشرين" رواه مسلم.

### فضل الاعتكاف في العشر الأواخر

من السنة الاعتكاف في العشر الأواخر من رمضان، اقتداءً بالنبي صلى الله عليه وسلم، فقد كان يعتكف العشر الأواخر من رمضان حتى توفاه الله تعالى.

عن عائشة رضي الله عنها قالت: "كان النبي صلى الله عليه وسلم يعتكف العشر الأواخر من رمضان حتى توفاه الله، ثم اعتكف أزواجه من بعده" رواه البخاري ومسلم.

والاعتكاف هو لزوم المسجد للعبادة والطاعة، وقطع العلائق عن الخلائق للاتصال بخدمة الخالق.

### أعمال مستحبة في العشر الأواخر

1. **إحياء الليل بالصلاة والذكر والدعاء**: عن عائشة رضي الله عنها قالت: "كان النبي صلى الله عليه وسلم يخلط العشرين بصلاة ونوم، فإذا كان العشر شمر وشد المئزر" رواه أحمد.

2. **الإكثار من الدعاء**: خاصة في الأوتار من الليالي، وفي الأسحار، فإنها أوقات إجابة.

3. **الإكثار من قراءة القرآن**: فشهر رمضان هو شهر القرآن، والعشر الأواخر أفضل أيامه.

4. **الإكثار من الصدقة**: فقد كان النبي صلى الله عليه وسلم أجود الناس، وكان أجود ما يكون في رمضان.

5. **الاجتهاد في العبادة عموماً**: من صلاة وذكر وصدقة وقراءة قرآن وغير ذلك من أنواع الطاعات.

## الخاتمة

إن العشر الأواخر من رمضان فرصة عظيمة للتقرب إلى الله تعالى، وتحصيل الأجور العظيمة، وتكفير الذنوب والخطايا. فينبغي للمسلم أن يغتنم هذه الأيام المباركة، وأن يجتهد فيها في العبادة والطاعة، وأن يتحرى فيها ليلة القدر، عسى الله أن يكتبه من عتقائه من النار.

نسأل الله تعالى أن يوفقنا لاغتنام هذه الأيام المباركة، وأن يتقبل منا صالح الأعمال، وأن يجعلنا من عتقائه من النار.

والحمد لله رب العالمين، وصلى الله وسلم على نبينا محمد وعلى آله وصحبه أجمعين.`,
    author: 'د. محمد الصالح',
    date: '15 رمضان 1445',
    category: 'رمضان',
    views: 2350,
    relatedArticles: [
      { id: 2, title: 'أثر الصيام في تهذيب النفس' },
      { id: 7, title: 'فضل ليلة القدر وعلاماتها' },
      { id: 9, title: 'الاعتكاف: أحكامه وفضائله' }
    ]
  };

  // Convert markdown-like content to HTML (simple version)
  const formatContent = (content) => {
    let formattedContent = content
      .replace(/^# (.*$)/gm, '<h1>$1</h1>')
      .replace(/^## (.*$)/gm, '<h2>$1</h2>')
      .replace(/^### (.*$)/gm, '<h3>$1</h3>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\n\n/g, '</p><p>');
    
    return <div dangerouslySetInnerHTML={{ __html: formattedContent }} />;
  };

  return (
    <div className="container mt-5">
      <div className="row">
        {/* Main Content Area */}
        <div className="col-12 col-md-8">
          <div className="card">
            {/* Article Title */}
            <h1 className="mb-4">{article.title}</h1>
            
            {/* Article Meta */}
            <div className="article-meta mb-4">
              <span className="mr-3">
                <i className="fas fa-user ml-1"></i> {article.author}
              </span>
              <span className="mr-3">
                <i className="far fa-calendar-alt ml-1"></i> {article.date}
              </span>
              <span className="mr-3">
                <i className="fas fa-folder ml-1"></i> {article.category}
              </span>
              <span>
                <i className="fas fa-eye ml-1"></i> {article.views} مشاهدة
              </span>
            </div>
            
            {/* Article Content */}
            <div className="article-content mb-4">
              {formatContent(article.content)}
            </div>
            
            {/* Share Buttons */}
            <div className="share-buttons mb-4">
              <h3 className="mb-2">مشاركة:</h3>
              <button className="btn btn-outline-primary ml-2">
                <i className="fab fa-facebook-f ml-1"></i> فيسبوك
              </button>
              <button className="btn btn-outline-info ml-2">
                <i className="fab fa-twitter ml-1"></i> تويتر
              </button>
              <button className="btn btn-outline-success ml-2">
                <i className="fab fa-whatsapp ml-1"></i> واتساب
              </button>
              <button className="btn btn-outline-secondary">
                <i className="fas fa-print ml-1"></i> طباعة
              </button>
            </div>
            
            {/* Related Articles */}
            <div className="related-articles">
              <h3 className="mb-3">مقالات ذات صلة:</h3>
              <ul className="list-unstyled">
                {article.relatedArticles.map(related => (
                  <li key={related.id} className="mb-2">
                    <Link to={`/articles/${related.id}`}>
                      <i className="fas fa-chevron-left ml-2"></i>
                      {related.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
        
        {/* Sidebar */}
        <div className="col-12 col-md-4">
          <div className="sticky-top" style={{ top: '20px' }}>
            {/* Author Info Widget */}
            <div className="card mb-4">
              <h3 className="section-title">عن الكاتب</h3>
              <div className="author-info">
                <div className="text-center mb-3">
                  <img 
                    src="https://via.placeholder.com/100" 
                    alt={article.author} 
                    className="rounded-circle" 
                    width="100" 
                    height="100" 
                  />
                </div>
                <h4 className="text-center mb-3">{article.author}</h4>
                <p>
                  كاتب ومفكر إسلامي، له العديد من المؤلفات والمقالات في مجال الفقه والعقيدة والدعوة.
                </p>
                <div className="text-center mt-3">
                  <a href={`/author/${article.author}`} className="btn btn-primary">عرض جميع مقالات الكاتب</a>
                </div>
              </div>
            </div>
            
            {/* Categories Widget */}
            <CategoryList />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ArticleDetails;

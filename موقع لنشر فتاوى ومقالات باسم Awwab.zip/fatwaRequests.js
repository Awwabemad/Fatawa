const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const FatwaRequest = require('../models/FatwaRequest');
const Fatwa = require('../models/Fatwa');

// @desc    Get all fatwa requests
// @route   GET /api/v1/fatwa-requests
// @access  Private (Admin/Scholar)
exports.getFatwaRequests = asyncHandler(async (req, res, next) => {
  // Check if user is scholar or admin
  if (req.user.role !== 'scholar' && req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بعرض طلبات الفتاوى`,
        403
      )
    );
  }

  res.status(200).json(res.advancedResults);
});

// @desc    Get single fatwa request
// @route   GET /api/v1/fatwa-requests/:id
// @access  Private (Admin/Scholar/Owner)
exports.getFatwaRequest = asyncHandler(async (req, res, next) => {
  const fatwaRequest = await FatwaRequest.findById(req.params.id);

  if (!fatwaRequest) {
    return next(
      new ErrorResponse(`لا يوجد طلب فتوى بهذا المعرف ${req.params.id}`, 404)
    );
  }

  // Make sure user is the request owner, scholar or admin
  if (
    fatwaRequest.userId.toString() !== req.user.id &&
    req.user.role !== 'scholar' &&
    req.user.role !== 'admin' &&
    req.user.role !== 'super_admin'
  ) {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بعرض هذا الطلب`,
        403
      )
    );
  }

  res.status(200).json({
    success: true,
    data: fatwaRequest
  });
});

// @desc    Create new fatwa request
// @route   POST /api/v1/fatwa-requests
// @access  Private
exports.createFatwaRequest = asyncHandler(async (req, res, next) => {
  // Add user to req.body
  req.body.userId = req.user.id;

  const fatwaRequest = await FatwaRequest.create(req.body);

  res.status(201).json({
    success: true,
    data: fatwaRequest
  });
});

// @desc    Update fatwa request status
// @route   PUT /api/v1/fatwa-requests/:id
// @access  Private (Admin/Scholar)
exports.updateFatwaRequestStatus = asyncHandler(async (req, res, next) => {
  // Check if user is scholar or admin
  if (req.user.role !== 'scholar' && req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بتحديث طلبات الفتاوى`,
        403
      )
    );
  }

  let fatwaRequest = await FatwaRequest.findById(req.params.id);

  if (!fatwaRequest) {
    return next(
      new ErrorResponse(`لا يوجد طلب فتوى بهذا المعرف ${req.params.id}`, 404)
    );
  }

  // Check if status is valid
  if (!['pending', 'answered', 'rejected'].includes(req.body.status)) {
    return next(
      new ErrorResponse(`الحالة غير صالحة: ${req.body.status}`, 400)
    );
  }

  // If status is 'answered', make sure fatwaId is provided
  if (req.body.status === 'answered' && !req.body.fatwaId) {
    return next(
      new ErrorResponse('يجب تحديد معرف الفتوى عند تغيير الحالة إلى "تمت الإجابة"', 400)
    );
  }

  // If status is 'rejected', make sure rejectionReason is provided
  if (req.body.status === 'rejected' && !req.body.rejectionReason) {
    return next(
      new ErrorResponse('يجب تحديد سبب الرفض عند تغيير الحالة إلى "مرفوض"', 400)
    );
  }

  // Update fatwa request
  fatwaRequest = await FatwaRequest.findByIdAndUpdate(
    req.params.id,
    {
      status: req.body.status,
      fatwaId: req.body.fatwaId || null,
      rejectionReason: req.body.rejectionReason || null
    },
    {
      new: true,
      runValidators: true
    }
  );

  res.status(200).json({
    success: true,
    data: fatwaRequest
  });
});

// @desc    Get user's fatwa requests
// @route   GET /api/v1/fatwa-requests/my-requests
// @access  Private
exports.getMyFatwaRequests = asyncHandler(async (req, res, next) => {
  const fatwaRequests = await FatwaRequest.find({ userId: req.user.id });

  res.status(200).json({
    success: true,
    count: fatwaRequests.length,
    data: fatwaRequests
  });
});

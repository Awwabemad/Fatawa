const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Comment = require('../models/Comment');

// @desc    Get all comments
// @route   GET /api/v1/comments
// @access  Private (Admin)
exports.getComments = asyncHandler(async (req, res, next) => {
  // Check if user is admin
  if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بعرض جميع التعليقات`,
        403
      )
    );
  }

  res.status(200).json(res.advancedResults);
});

// @desc    Get comments for a specific item
// @route   GET /api/v1/comments/:itemType/:itemId
// @access  Public
exports.getItemComments = asyncHandler(async (req, res, next) => {
  const { itemType, itemId } = req.params;

  // Validate item type
  if (!['fatwa', 'article'].includes(itemType)) {
    return next(
      new ErrorResponse(`نوع العنصر غير صالح: ${itemType}`, 400)
    );
  }

  const comments = await Comment.find({
    itemId,
    itemType,
    status: 'approved'
  }).populate({
    path: 'userId',
    select: 'fullName username profileImage'
  }).sort({ createdAt: -1 });

  res.status(200).json({
    success: true,
    count: comments.length,
    data: comments
  });
});

// @desc    Add comment
// @route   POST /api/v1/comments
// @access  Private
exports.addComment = asyncHandler(async (req, res, next) => {
  // Add user to req.body
  req.body.userId = req.user.id;

  // Validate item type
  if (!['fatwa', 'article'].includes(req.body.itemType)) {
    return next(
      new ErrorResponse(`نوع العنصر غير صالح: ${req.body.itemType}`, 400)
    );
  }

  const comment = await Comment.create(req.body);

  res.status(201).json({
    success: true,
    data: comment
  });
});

// @desc    Update comment status
// @route   PUT /api/v1/comments/:id
// @access  Private (Admin)
exports.updateCommentStatus = asyncHandler(async (req, res, next) => {
  // Check if user is admin
  if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بتحديث حالة التعليقات`,
        403
      )
    );
  }

  let comment = await Comment.findById(req.params.id);

  if (!comment) {
    return next(
      new ErrorResponse(`لا يوجد تعليق بهذا المعرف ${req.params.id}`, 404)
    );
  }

  // Check if status is valid
  if (!['pending', 'approved', 'rejected'].includes(req.body.status)) {
    return next(
      new ErrorResponse(`الحالة غير صالحة: ${req.body.status}`, 400)
    );
  }

  // If status is 'rejected', make sure rejectionReason is provided
  if (req.body.status === 'rejected' && !req.body.rejectionReason) {
    return next(
      new ErrorResponse('يجب تحديد سبب الرفض عند تغيير الحالة إلى "مرفوض"', 400)
    );
  }

  // Update comment
  comment = await Comment.findByIdAndUpdate(
    req.params.id,
    {
      status: req.body.status,
      rejectionReason: req.body.rejectionReason || null
    },
    {
      new: true,
      runValidators: true
    }
  );

  res.status(200).json({
    success: true,
    data: comment
  });
});

// @desc    Delete comment
// @route   DELETE /api/v1/comments/:id
// @access  Private (Admin/Owner)
exports.deleteComment = asyncHandler(async (req, res, next) => {
  const comment = await Comment.findById(req.params.id);

  if (!comment) {
    return next(
      new ErrorResponse(`لا يوجد تعليق بهذا المعرف ${req.params.id}`, 404)
    );
  }

  // Make sure user is comment owner or admin
  if (
    comment.userId.toString() !== req.user.id &&
    req.user.role !== 'admin' &&
    req.user.role !== 'super_admin'
  ) {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بحذف هذا التعليق`,
        403
      )
    );
  }

  await comment.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Get user's comments
// @route   GET /api/v1/comments/my-comments
// @access  Private
exports.getMyComments = asyncHandler(async (req, res, next) => {
  const comments = await Comment.find({ userId: req.user.id });

  res.status(200).json({
    success: true,
    count: comments.length,
    data: comments
  });
});

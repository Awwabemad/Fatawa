import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Register = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    agreeTerms: false
  });

  const { fullName, email, password, confirmPassword, agreeTerms } = formData;

  const onChange = e => {
    const { name, value, checked, type } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const onSubmit = e => {
    e.preventDefault();
    // Registration logic would go here in a real application
    if (password !== confirmPassword) {
      console.error('كلمات المرور غير متطابقة');
    } else {
      console.log('Registration form submitted', formData);
    }
  };

  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-md-6 mx-auto">
          <div className="card">
            <div className="card-body">
              <h1 className="text-center mb-4">إنشاء حساب جديد</h1>
              
              <form onSubmit={onSubmit}>
                <div className="form-group mb-3">
                  <label htmlFor="fullName">الاسم الكامل</label>
                  <input
                    type="text"
                    className="form-control"
                    id="fullName"
                    name="fullName"
                    value={fullName}
                    onChange={onChange}
                    required
                  />
                </div>
                
                <div className="form-group mb-3">
                  <label htmlFor="email">البريد الإلكتروني</label>
                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    name="email"
                    value={email}
                    onChange={onChange}
                    required
                  />
                </div>
                
                <div className="form-group mb-3">
                  <label htmlFor="password">كلمة المرور</label>
                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    name="password"
                    value={password}
                    onChange={onChange}
                    required
                    minLength="6"
                  />
                  <small className="form-text text-muted">
                    يجب أن تتكون كلمة المرور من 6 أحرف على الأقل
                  </small>
                </div>
                
                <div className="form-group mb-3">
                  <label htmlFor="confirmPassword">تأكيد كلمة المرور</label>
                  <input
                    type="password"
                    className="form-control"
                    id="confirmPassword"
                    name="confirmPassword"
                    value={confirmPassword}
                    onChange={onChange}
                    required
                    minLength="6"
                  />
                </div>
                
                <div className="form-group mb-3">
                  <div className="form-check">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="agreeTerms"
                      name="agreeTerms"
                      checked={agreeTerms}
                      onChange={onChange}
                      required
                    />
                    <label className="form-check-label" htmlFor="agreeTerms">
                      أوافق على <Link to="/terms">شروط الاستخدام</Link> و <Link to="/privacy">سياسة الخصوصية</Link>
                    </label>
                  </div>
                </div>
                
                <button type="submit" className="btn btn-primary btn-block w-100 mb-3">
                  إنشاء حساب
                </button>
              </form>
              
              <hr />
              
              <div className="text-center">
                <p>لديك حساب بالفعل؟</p>
                <Link to="/login" className="btn btn-outline-primary">
                  تسجيل الدخول
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;

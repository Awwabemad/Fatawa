import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const CommentsList = () => {
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Mock data for demonstration
  useEffect(() => {
    // In a real application, this would fetch data from the backend API
    const mockComments = [
      {
        _id: '1',
        content: 'جزاكم الله خيراً على هذه الفتوى القيمة',
        status: 'approved',
        userId: {
          _id: '201',
          fullName: 'محمد أحمد',
          username: 'mohammed123'
        },
        itemId: '1',
        itemType: 'fatwa',
        createdAt: '2025-04-01T10:30:00',
        rejectionReason: null
      },
      {
        _id: '2',
        content: 'هل يمكن توضيح المسألة بشكل أكثر تفصيلاً؟',
        status: 'pending',
        userId: {
          _id: '202',
          fullName: 'أحمد علي',
          username: 'ahmed456'
        },
        itemId: '2',
        itemType: 'fatwa',
        createdAt: '2025-04-02T14:15:00',
        rejectionReason: null
      },
      {
        _id: '3',
        content: 'مقال رائع ومفيد، بارك الله فيكم',
        status: 'approved',
        userId: {
          _id: '203',
          fullName: 'خالد محمد',
          username: 'khaled789'
        },
        itemId: '1',
        itemType: 'article',
        createdAt: '2025-03-25T09:45:00',
        rejectionReason: null
      },
      {
        _id: '4',
        content: 'أرجو إضافة المزيد من المراجع للاستفادة',
        status: 'approved',
        userId: {
          _id: '204',
          fullName: 'فاطمة أحمد',
          username: 'fatima123'
        },
        itemId: '2',
        itemType: 'article',
        createdAt: '2025-03-20T16:30:00',
        rejectionReason: null
      },
      {
        _id: '5',
        content: 'هذا التعليق يحتوي على كلام غير لائق ومخالف لسياسة الموقع',
        status: 'rejected',
        userId: {
          _id: '205',
          fullName: 'عمر خالد',
          username: 'omar456'
        },
        itemId: '3',
        itemType: 'fatwa',
        createdAt: '2025-03-15T11:20:00',
        rejectionReason: 'التعليق يحتوي على كلام غير لائق ومخالف لسياسة الموقع'
      }
    ];

    // Filter comments based on status filter
    let filteredComments = [...mockComments];
    if (filter !== 'all') {
      filteredComments = mockComments.filter(comment => comment.status === filter);
    }

    // Filter by search term
    if (searchTerm) {
      filteredComments = filteredComments.filter(
        comment => 
          comment.content.includes(searchTerm) || 
          comment.userId.fullName.includes(searchTerm) ||
          comment.userId.username.includes(searchTerm)
      );
    }

    setComments(filteredComments);
    setTotalPages(Math.ceil(filteredComments.length / 10));
    setLoading(false);
  }, [filter, searchTerm]);

  // Format date to Arabic format
  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Get status badge
  const getStatusBadge = (status) => {
    switch (status) {
      case 'pending':
        return <span className="badge bg-warning">قيد المراجعة</span>;
      case 'approved':
        return <span className="badge bg-success">معتمد</span>;
      case 'rejected':
        return <span className="badge bg-danger">مرفوض</span>;
      default:
        return <span className="badge bg-info">غير معروف</span>;
    }
  };

  // Get item type badge
  const getItemTypeBadge = (itemType) => {
    switch (itemType) {
      case 'fatwa':
        return <span className="badge bg-primary">فتوى</span>;
      case 'article':
        return <span className="badge bg-success">مقال</span>;
      default:
        return <span className="badge bg-secondary">غير معروف</span>;
    }
  };

  const handleFilterChange = (e) => {
    setFilter(e.target.value);
    setCurrentPage(1);
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    // Search is already handled by the useEffect
  };

  return (
    <div className="container-fluid mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1>إدارة التعليقات</h1>
      </div>
      
      <div className="card mb-4">
        <div className="card-body">
          <div className="row">
            <div className="col-md-6">
              <form onSubmit={handleSearchSubmit}>
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="البحث في التعليقات..."
                    value={searchTerm}
                    onChange={handleSearchChange}
                  />
                  <button className="btn btn-outline-secondary" type="submit">
                    <i className="fas fa-search"></i>
                  </button>
                </div>
              </form>
            </div>
            <div className="col-md-6">
              <div className="d-flex justify-content-end">
                <select
                  className="form-select w-auto"
                  value={filter}
                  onChange={handleFilterChange}
                >
                  <option value="all">جميع التعليقات</option>
                  <option value="pending">قيد المراجعة</option>
                  <option value="approved">معتمدة</option>
                  <option value="rejected">مرفوضة</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {loading ? (
        <div className="text-center my-5">
          <div className="spinner-border text-info" role="status">
            <span className="visually-hidden">جاري التحميل...</span>
          </div>
          <p className="mt-2">جاري تحميل التعليقات...</p>
        </div>
      ) : (
        <>
          <div className="table-responsive">
            <table className="table table-striped table-hover">
              <thead className="table-light">
                <tr>
                  <th>التعليق</th>
                  <th>المستخدم</th>
                  <th>النوع</th>
                  <th>تاريخ التعليق</th>
                  <th>الحالة</th>
                  <th>الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {comments.length > 0 ? (
                  comments.map(comment => (
                    <tr key={comment._id}>
                      <td>
                        {comment.content.length > 100 
                          ? `${comment.content.substring(0, 100)}...` 
                          : comment.content}
                      </td>
                      <td>{comment.userId.fullName}</td>
                      <td>{getItemTypeBadge(comment.itemType)}</td>
                      <td>{formatDate(comment.createdAt)}</td>
                      <td>{getStatusBadge(comment.status)}</td>
                      <td>
                        <div className="btn-group btn-group-sm">
                          <Link to={`/admin/comments/${comment._id}`} className="btn btn-outline-info">
                            <i className="fas fa-eye"></i>
                          </Link>
                          {comment.status === 'pending' && (
                            <>
                              <button className="btn btn-outline-success">
                                <i className="fas fa-check-circle"></i>
                              </button>
                              <button className="btn btn-outline-danger">
                                <i className="fas fa-times-circle"></i>
                              </button>
                            </>
                          )}
                          <Link 
                            to={`/admin/${comment.itemType}s/${comment.itemId}`} 
                            className="btn btn-outline-primary"
                          >
                            <i className="fas fa-link"></i>
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center py-4">
                      لا توجد تعليقات متطابقة مع معايير البحث
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          {totalPages > 1 && (
            <nav aria-label="Page navigation" className="mt-4">
              <ul className="pagination justify-content-center">
                <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                  <button
                    className="page-link"
                    onClick={() => setCurrentPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    السابق
                  </button>
                </li>
                
                {[...Array(totalPages)].map((_, index) => (
                  <li
                    key={index}
                    className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}
                  >
                    <button
                      className="page-link"
                      onClick={() => setCurrentPage(index + 1)}
                    >
                      {index + 1}
                    </button>
                  </li>
                ))}
                
                <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                  <button
                    className="page-link"
                    onClick={() => setCurrentPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    التالي
                  </button>
                </li>
              </ul>
            </nav>
          )}
        </>
      )}
    </div>
  );
};

export default CommentsList;

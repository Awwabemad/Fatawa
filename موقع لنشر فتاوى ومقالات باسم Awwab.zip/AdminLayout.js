import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';

// Admin components
import Dashboard from './pages/admin/Dashboard';
import FatwasList from './pages/admin/FatwasList';
import ArticlesList from './pages/admin/ArticlesList';
import FatwaRequestsList from './pages/admin/FatwaRequestsList';
import CommentsList from './pages/admin/CommentsList';
import FatwaForm from './components/admin/FatwaForm';
import ArticleForm from './components/admin/ArticleForm';

const AdminLayout = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [currentUser, setCurrentUser] = useState({
    fullName: 'الشيخ أحمد',
    role: 'scholar',
    profileImage: 'https://via.placeholder.com/50'
  });
  
  const navigate = useNavigate();
  
  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };
  
  const handleLogout = () => {
    // In a real application, this would call the logout API
    console.log('Logging out...');
    navigate('/login');
  };
  
  return (
    <div className="admin-layout d-flex">
      {/* Sidebar */}
      <div className={`sidebar bg-dark text-white ${sidebarCollapsed ? 'collapsed' : ''}`}>
        <div className="sidebar-header p-3 border-bottom border-secondary">
          <div className="d-flex justify-content-between align-items-center">
            {!sidebarCollapsed && (
              <h3 className="m-0">لوحة الإدارة</h3>
            )}
            <button 
              className="btn btn-outline-light btn-sm" 
              onClick={toggleSidebar}
            >
              <i className={`fas fa-${sidebarCollapsed ? 'arrow-right' : 'arrow-left'}`}></i>
            </button>
          </div>
        </div>
        
        <div className="sidebar-content p-3">
          <ul className="nav flex-column">
            <li className="nav-item mb-2">
              <Link to="/admin" className="nav-link text-white">
                <i className="fas fa-tachometer-alt me-2"></i>
                {!sidebarCollapsed && 'الرئيسية'}
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link to="/admin/fatwas" className="nav-link text-white">
                <i className="fas fa-scroll me-2"></i>
                {!sidebarCollapsed && 'الفتاوى'}
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link to="/admin/articles" className="nav-link text-white">
                <i className="fas fa-newspaper me-2"></i>
                {!sidebarCollapsed && 'المقالات'}
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link to="/admin/fatwa-requests" className="nav-link text-white">
                <i className="fas fa-question-circle me-2"></i>
                {!sidebarCollapsed && 'طلبات الفتاوى'}
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link to="/admin/comments" className="nav-link text-white">
                <i className="fas fa-comments me-2"></i>
                {!sidebarCollapsed && 'التعليقات'}
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link to="/admin/categories" className="nav-link text-white">
                <i className="fas fa-folder me-2"></i>
                {!sidebarCollapsed && 'التصنيفات'}
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link to="/admin/tags" className="nav-link text-white">
                <i className="fas fa-tags me-2"></i>
                {!sidebarCollapsed && 'الوسوم'}
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link to="/admin/users" className="nav-link text-white">
                <i className="fas fa-users me-2"></i>
                {!sidebarCollapsed && 'المستخدمون'}
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link to="/admin/settings" className="nav-link text-white">
                <i className="fas fa-cog me-2"></i>
                {!sidebarCollapsed && 'الإعدادات'}
              </Link>
            </li>
          </ul>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="main-content flex-grow-1">
        {/* Top Navbar */}
        <nav className="navbar navbar-expand-lg navbar-light bg-white border-bottom">
          <div className="container-fluid">
            <ol className="breadcrumb m-0">
              <li className="breadcrumb-item"><Link to="/admin">لوحة الإدارة</Link></li>
              <li className="breadcrumb-item active">الرئيسية</li>
            </ol>
            
            <ul className="navbar-nav ms-auto">
              <li className="nav-item dropdown">
                <a 
                  className="nav-link dropdown-toggle" 
                  href="#" 
                  id="navbarDropdown" 
                  role="button" 
                  data-bs-toggle="dropdown" 
                  aria-expanded="false"
                >
                  <img 
                    src={currentUser.profileImage} 
                    alt={currentUser.fullName} 
                    className="rounded-circle me-2" 
                    width="30" 
                    height="30" 
                  />
                  {currentUser.fullName}
                </a>
                <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                  <li><Link className="dropdown-item" to="/admin/profile">الملف الشخصي</Link></li>
                  <li><Link className="dropdown-item" to="/admin/settings">الإعدادات</Link></li>
                  <li><hr className="dropdown-divider" /></li>
                  <li><button className="dropdown-item" onClick={handleLogout}>تسجيل الخروج</button></li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
        
        {/* Page Content */}
        <div className="page-content p-3">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/fatwas" element={<FatwasList />} />
            <Route path="/fatwas/new" element={<FatwaForm />} />
            <Route path="/fatwas/:id/edit" element={<FatwaForm isEditing={true} />} />
            <Route path="/articles" element={<ArticlesList />} />
            <Route path="/articles/new" element={<ArticleForm />} />
            <Route path="/articles/:id/edit" element={<ArticleForm isEditing={true} />} />
            <Route path="/fatwa-requests" element={<FatwaRequestsList />} />
            <Route path="/comments" element={<CommentsList />} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;

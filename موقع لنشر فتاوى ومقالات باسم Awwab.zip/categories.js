const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Category = require('../models/Category');

// @desc    Get all categories
// @route   GET /api/v1/categories
// @access  Public
exports.getCategories = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

// @desc    Get single category
// @route   GET /api/v1/categories/:id
// @access  Public
exports.getCategory = asyncHandler(async (req, res, next) => {
  const category = await Category.findById(req.params.id);

  if (!category) {
    return next(
      new ErrorResponse(`لا يوجد تصنيف بهذا المعرف ${req.params.id}`, 404)
    );
  }

  res.status(200).json({
    success: true,
    data: category
  });
});

// @desc    Create new category
// @route   POST /api/v1/categories
// @access  Private (Admin)
exports.createCategory = asyncHandler(async (req, res, next) => {
  // Check if user is admin
  if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بإضافة تصنيفات`,
        403
      )
    );
  }

  const category = await Category.create(req.body);

  res.status(201).json({
    success: true,
    data: category
  });
});

// @desc    Update category
// @route   PUT /api/v1/categories/:id
// @access  Private (Admin)
exports.updateCategory = asyncHandler(async (req, res, next) => {
  // Check if user is admin
  if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بتحديث التصنيفات`,
        403
      )
    );
  }

  let category = await Category.findById(req.params.id);

  if (!category) {
    return next(
      new ErrorResponse(`لا يوجد تصنيف بهذا المعرف ${req.params.id}`, 404)
    );
  }

  category = await Category.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: category
  });
});

// @desc    Delete category
// @route   DELETE /api/v1/categories/:id
// @access  Private (Admin)
exports.deleteCategory = asyncHandler(async (req, res, next) => {
  // Check if user is admin
  if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بحذف التصنيفات`,
        403
      )
    );
  }

  const category = await Category.findById(req.params.id);

  if (!category) {
    return next(
      new ErrorResponse(`لا يوجد تصنيف بهذا المعرف ${req.params.id}`, 404)
    );
  }

  await category.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Get categories by type
// @route   GET /api/v1/categories/type/:type
// @access  Public
exports.getCategoriesByType = asyncHandler(async (req, res, next) => {
  const { type } = req.params;
  
  if (!['fatwa', 'article', 'both'].includes(type)) {
    return next(
      new ErrorResponse(`نوع التصنيف غير صالح: ${type}`, 400)
    );
  }

  const categories = await Category.find({ 
    $or: [{ type }, { type: 'both' }] 
  });

  res.status(200).json({
    success: true,
    count: categories.length,
    data: categories
  });
});

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const AdvancedSearch = () => {
  const [searchParams, setSearchParams] = useState({
    keyword: '',
    type: 'all',
    category: '',
    tag: '',
    dateFrom: '',
    dateTo: ''
  });
  
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [categories, setCategories] = useState([]);
  const [tags, setTags] = useState([]);
  const [resultCount, setResultCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  
  // Mock data for demonstration
  useEffect(() => {
    // In a real application, these would be fetched from the backend API
    setCategories([
      { _id: '1', name: 'العقيدة', slug: 'aqeedah' },
      { _id: '2', name: 'العبادات', slug: 'worship' },
      { _id: '3', name: 'المعاملات', slug: 'transactions' },
      { _id: '4', name: 'الأسرة', slug: 'family' },
      { _id: '5', name: 'الأخلاق', slug: 'ethics' }
    ]);
    
    setTags([
      { _id: '1', name: 'رمضان', slug: 'ramadan' },
      { _id: '2', name: 'الصلاة', slug: 'prayer' },
      { _id: '3', name: 'الزكاة', slug: 'zakat' },
      { _id: '4', name: 'الحج', slug: 'hajj' },
      { _id: '5', name: 'الصيام', slug: 'fasting' }
    ]);
  }, []);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSearchParams({
      ...searchParams,
      [name]: value
    });
  };
  
  const handleSearch = (e) => {
    e.preventDefault();
    setLoading(true);
    
    // In a real application, this would call the backend API
    setTimeout(() => {
      // Mock search results
      const mockResults = [
        {
          _id: '1',
          title: 'حكم صيام الست من شوال',
          type: 'fatwa',
          excerpt: 'صيام ستة أيام من شوال بعد رمضان سنة مستحبة، وليست واجبة، ويجوز أن تكون متتابعة أو متفرقة...',
          date: '2025-03-20T14:45:00',
          category: { _id: '2', name: 'العبادات', slug: 'worship' },
          tags: [
            { _id: '1', name: 'رمضان', slug: 'ramadan' },
            { _id: '5', name: 'الصيام', slug: 'fasting' }
          ],
          url: '/fatwas/1'
        },
        {
          _id: '2',
          title: 'زكاة المال المستثمر في الأسهم',
          type: 'fatwa',
          excerpt: 'تجب الزكاة في الأسهم المستثمرة للتجارة، وتحسب قيمتها السوقية يوم وجوب الزكاة...',
          date: '2025-03-18T11:30:00',
          category: { _id: '3', name: 'المعاملات', slug: 'transactions' },
          tags: [
            { _id: '3', name: 'الزكاة', slug: 'zakat' }
          ],
          url: '/fatwas/2'
        },
        {
          _id: '3',
          title: 'فضل العشر الأواخر من رمضان',
          type: 'article',
          excerpt: 'العشر الأواخر من رمضان هي أفضل أيام الشهر الكريم، وفيها ليلة القدر التي هي خير من ألف شهر...',
          date: '2025-03-20T14:45:00',
          category: { _id: '2', name: 'العبادات', slug: 'worship' },
          tags: [
            { _id: '1', name: 'رمضان', slug: 'ramadan' },
            { _id: '5', name: 'الصيام', slug: 'fasting' }
          ],
          url: '/articles/1'
        },
        {
          _id: '4',
          title: 'أثر الصيام في تهذيب النفس',
          type: 'article',
          excerpt: 'الصيام من أعظم العبادات التي تهذب النفس وتزكيها، وتقوي الإرادة وتعلم الصبر...',
          date: '2025-03-18T11:30:00',
          category: { _id: '5', name: 'الأخلاق', slug: 'ethics' },
          tags: [
            { _id: '1', name: 'رمضان', slug: 'ramadan' },
            { _id: '5', name: 'الصيام', slug: 'fasting' }
          ],
          url: '/articles/2'
        },
        {
          _id: '5',
          title: 'حكم صلاة التراويح في المنزل',
          type: 'fatwa',
          excerpt: 'صلاة التراويح سنة مؤكدة، والأفضل أداؤها في المسجد جماعة، ولكن يجوز أداؤها في المنزل...',
          date: '2025-03-28T10:15:00',
          category: { _id: '2', name: 'العبادات', slug: 'worship' },
          tags: [
            { _id: '1', name: 'رمضان', slug: 'ramadan' },
            { _id: '2', name: 'الصلاة', slug: 'prayer' }
          ],
          url: '/fatwas/4'
        }
      ];
      
      // Filter results based on search parameters
      let filteredResults = [...mockResults];
      
      if (searchParams.keyword) {
        const keyword = searchParams.keyword.toLowerCase();
        filteredResults = filteredResults.filter(
          result => 
            result.title.toLowerCase().includes(keyword) || 
            result.excerpt.toLowerCase().includes(keyword)
        );
      }
      
      if (searchParams.type !== 'all') {
        filteredResults = filteredResults.filter(
          result => result.type === searchParams.type
        );
      }
      
      if (searchParams.category) {
        filteredResults = filteredResults.filter(
          result => result.category._id === searchParams.category
        );
      }
      
      if (searchParams.tag) {
        filteredResults = filteredResults.filter(
          result => result.tags.some(tag => tag._id === searchParams.tag)
        );
      }
      
      if (searchParams.dateFrom) {
        const fromDate = new Date(searchParams.dateFrom);
        filteredResults = filteredResults.filter(
          result => new Date(result.date) >= fromDate
        );
      }
      
      if (searchParams.dateTo) {
        const toDate = new Date(searchParams.dateTo);
        toDate.setHours(23, 59, 59, 999); // End of the day
        filteredResults = filteredResults.filter(
          result => new Date(result.date) <= toDate
        );
      }
      
      setSearchResults(filteredResults);
      setResultCount(filteredResults.length);
      setTotalPages(Math.ceil(filteredResults.length / 10));
      setLoading(false);
    }, 1000);
  };
  
  // Format date to Arabic format
  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Get content type badge
  const getTypeBadge = (type) => {
    switch (type) {
      case 'fatwa':
        return <span className="badge bg-primary">فتوى</span>;
      case 'article':
        return <span className="badge bg-success">مقال</span>;
      default:
        return <span className="badge bg-secondary">غير معروف</span>;
    }
  };
  
  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-12">
          <h1 className="mb-4">البحث المتقدم</h1>
          
          <div className="card mb-4">
            <div className="card-body">
              <form onSubmit={handleSearch}>
                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label htmlFor="keyword" className="form-label">كلمات البحث</label>
                    <input
                      type="text"
                      className="form-control"
                      id="keyword"
                      name="keyword"
                      value={searchParams.keyword}
                      onChange={handleInputChange}
                      placeholder="أدخل كلمات البحث..."
                    />
                  </div>
                  
                  <div className="col-md-6 mb-3">
                    <label htmlFor="type" className="form-label">نوع المحتوى</label>
                    <select
                      className="form-select"
                      id="type"
                      name="type"
                      value={searchParams.type}
                      onChange={handleInputChange}
                    >
                      <option value="all">الكل</option>
                      <option value="fatwa">الفتاوى</option>
                      <option value="article">المقالات</option>
                    </select>
                  </div>
                </div>
                
                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label htmlFor="category" className="form-label">التصنيف</label>
                    <select
                      className="form-select"
                      id="category"
                      name="category"
                      value={searchParams.category}
                      onChange={handleInputChange}
                    >
                      <option value="">اختر التصنيف...</option>
                      {categories.map(category => (
                        <option key={category._id} value={category._id}>
                          {category.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="col-md-6 mb-3">
                    <label htmlFor="tag" className="form-label">الوسم</label>
                    <select
                      className="form-select"
                      id="tag"
                      name="tag"
                      value={searchParams.tag}
                      onChange={handleInputChange}
                    >
                      <option value="">اختر الوسم...</option>
                      {tags.map(tag => (
                        <option key={tag._id} value={tag._id}>
                          {tag.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                
                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label htmlFor="dateFrom" className="form-label">من تاريخ</label>
                    <input
                      type="date"
                      className="form-control"
                      id="dateFrom"
                      name="dateFrom"
                      value={searchParams.dateFrom}
                      onChange={handleInputChange}
                    />
                  </div>
                  
                  <div className="col-md-6 mb-3">
                    <label htmlFor="dateTo" className="form-label">إلى تاريخ</label>
                    <input
                      type="date"
                      className="form-control"
                      id="dateTo"
                      name="dateTo"
                      value={searchParams.dateTo}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                
                <div className="d-grid">
                  <button type="submit" className="btn btn-primary btn-lg">
                    <i className="fas fa-search me-2"></i>
                    بحث
                  </button>
                </div>
              </form>
            </div>
          </div>
          
          {loading ? (
            <div className="text-center my-5">
              <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">جاري البحث...</span>
              </div>
              <p className="mt-2">جاري البحث...</p>
            </div>
          ) : (
            searchResults.length > 0 && (
              <div className="search-results">
                <h2 className="mb-3">نتائج البحث ({resultCount})</h2>
                
                <div className="list-group">
                  {searchResults.map(result => (
                    <div key={`${result.type}-${result._id}`} className="list-group-item list-group-item-action">
                      <div className="d-flex w-100 justify-content-between align-items-center mb-2">
                        <h5 className="mb-0">
                          <Link to={result.url} className="text-decoration-none">
                            {result.title}
                          </Link>
                        </h5>
                        {getTypeBadge(result.type)}
                      </div>
                      <p className="mb-2">{result.excerpt}</p>
                      <div className="d-flex justify-content-between align-items-center">
                        <div>
                          <span className="badge bg-secondary me-2">{result.category.name}</span>
                          {result.tags.map(tag => (
                            <span key={tag._id} className="badge bg-light text-dark me-1">
                              {tag.name}
                            </span>
                          ))}
                        </div>
                        <small className="text-muted">{formatDate(result.date)}</small>
                      </div>
                    </div>
                  ))}
                </div>
                
                {totalPages > 1 && (
                  <nav aria-label="Page navigation" className="mt-4">
                    <ul className="pagination justify-content-center">
                      <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                        <button
                          className="page-link"
                          onClick={() => setCurrentPage(currentPage - 1)}
                          disabled={currentPage === 1}
                        >
                          السابق
                        </button>
                      </li>
                      
                      {[...Array(totalPages)].map((_, index) => (
                        <li
                          key={index}
                          className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}
                        >
                          <button
                            className="page-link"
                            onClick={() => setCurrentPage(index + 1)}
                          >
                            {index + 1}
                          </button>
                        </li>
                      ))}
                      
                      <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                        <button
                          className="page-link"
                          onClick={() => setCurrentPage(currentPage + 1)}
                          disabled={currentPage === totalPages}
                        >
                          التالي
                        </button>
                      </li>
                    </ul>
                  </nav>
                )}
              </div>
            )
          )}
          
          {!loading && searchResults.length === 0 && searchParams.keyword && (
            <div className="alert alert-info text-center" role="alert">
              <i className="fas fa-info-circle me-2"></i>
              لم يتم العثور على نتائج مطابقة لمعايير البحث
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdvancedSearch;

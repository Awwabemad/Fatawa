import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="row">
          <div className="col-12 col-md-4 mb-4">
            <h3 className="footer-title">أوّاب</h3>
            <p>
              موقع أوّاب للفتاوى والمقالات الإسلامية يهدف إلى نشر العلم الشرعي الصحيح وتقديم الفتاوى والمقالات الإسلامية الموثوقة.
            </p>
          </div>
          
          <div className="col-12 col-md-4 mb-4">
            <h3 className="footer-title">روابط سريعة</h3>
            <ul className="footer-links">
              <li className="footer-link">
                <Link to="/">الرئيسية</Link>
              </li>
              <li className="footer-link">
                <Link to="/fatwas">الفتاوى</Link>
              </li>
              <li className="footer-link">
                <Link to="/articles">المقالات</Link>
              </li>
              <li className="footer-link">
                <Link to="/login">تسجيل الدخول</Link>
              </li>
              <li className="footer-link">
                <Link to="/register">إنشاء حساب</Link>
              </li>
            </ul>
          </div>
          
          <div className="col-12 col-md-4 mb-4">
            <h3 className="footer-title">تواصل معنا</h3>
            <ul className="footer-links">
              <li className="footer-link">
                <i className="fas fa-envelope ml-2"></i> info@awwab.com
              </li>
              <li className="footer-link">
                <i className="fas fa-phone ml-2"></i> +123456789
              </li>
              <li className="footer-link">
                <div className="mt-3">
                  <a href="#" className="ml-2 text-primary" aria-label="فيسبوك">
                    <i className="fab fa-facebook fa-lg"></i>
                  </a>
                  <a href="#" className="ml-2 text-primary" aria-label="تويتر">
                    <i className="fab fa-twitter fa-lg"></i>
                  </a>
                  <a href="#" className="ml-2 text-primary" aria-label="انستغرام">
                    <i className="fab fa-instagram fa-lg"></i>
                  </a>
                  <a href="#" className="ml-2 text-primary" aria-label="يوتيوب">
                    <i className="fab fa-youtube fa-lg"></i>
                  </a>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>جميع الحقوق محفوظة &copy; {new Date().getFullYear()} - موقع أوّاب للفتاوى والمقالات الإسلامية</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

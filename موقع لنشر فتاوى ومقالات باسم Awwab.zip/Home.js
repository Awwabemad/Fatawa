import React from 'react';
import SearchBar from '../components/common/SearchBar';
import FatwaCard from '../components/common/FatwaCard';
import ArticleCard from '../components/common/ArticleCard';
import CategoryList from '../components/common/CategoryList';

const Home = () => {
  // Mock data for featured fatwas
  const featuredFatwas = [
    {
      id: '1',
      title: 'حكم صلاة التراويح في المنزل',
      question: 'ما حكم صلاة التراويح في المنزل بدلاً من المسجد؟ وهل يجوز أن أصليها منفرداً؟',
      scholar: 'الشيخ عبد الله',
      date: '15 رمضان 1445',
      category: 'العبادات'
    },
    {
      id: '2',
      title: 'زكاة المال المستثمر في الأسهم',
      question: 'كيف أحسب زكاة المال المستثمر في الأسهم والصناديق الاستثمارية؟',
      scholar: 'الشيخ محمد',
      date: '10 رمضان 1445',
      category: 'المعاملات'
    },
    {
      id: '3',
      title: 'حكم استخدام وسائل التواصل الاجتماعي',
      question: 'ما حكم استخدام وسائل التواصل الاجتماعي للدعوة إلى الله؟ وما ضوابط ذلك؟',
      scholar: 'الشيخ أحمد',
      date: '5 رمضان 1445',
      category: 'الدعوة'
    }
  ];

  // Mock data for latest articles
  const latestArticles = [
    {
      id: '1',
      title: 'فضل العشر الأواخر من رمضان',
      content: 'تعتبر العشر الأواخر من شهر رمضان المبارك من أفضل أيام العام، حيث تتضاعف فيها الأجور وتُرفع فيها الدرجات...',
      author: 'د. محمد الصالح',
      date: '15 رمضان 1445',
      category: 'رمضان'
    },
    {
      id: '2',
      title: 'أثر الصيام في تهذيب النفس',
      content: 'للصيام أثر عظيم في تهذيب النفس وتزكيتها، فهو مدرسة روحية وتربوية يتعلم فيها المسلم الصبر والإرادة...',
      author: 'د. أحمد العبد الله',
      date: '10 رمضان 1445',
      category: 'الأخلاق'
    },
    {
      id: '3',
      title: 'الوسطية في الإسلام',
      content: 'تعد الوسطية من أهم خصائص الدين الإسلامي، فهي منهج رباني يقوم على التوازن والاعتدال في كل شؤون الحياة...',
      author: 'د. عبد الرحمن',
      date: '5 رمضان 1445',
      category: 'العقيدة'
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="hero">
        <div className="container">
          <div className="row">
            <div className="col-12 col-md-8 mx-auto text-center">
              <h1 className="hero-title">أوّاب للفتاوى والمقالات الإسلامية</h1>
              <p className="hero-subtitle">منصة إسلامية موثوقة لنشر العلم الشرعي والفتاوى الإسلامية</p>
              <SearchBar placeholder="ابحث في الفتاوى والمقالات..." />
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="container mt-5">
        <div className="row">
          {/* Main Content Area */}
          <div className="col-12 col-md-8">
            {/* Featured Fatwas Section */}
            <section className="mb-5">
              <h2 className="section-title">فتاوى مختارة</h2>
              <div className="row">
                {featuredFatwas.map(fatwa => (
                  <div key={fatwa.id} className="col-12 mb-4">
                    <FatwaCard fatwa={fatwa} />
                  </div>
                ))}
              </div>
            </section>

            {/* Latest Articles Section */}
            <section className="mb-5">
              <h2 className="section-title">أحدث المقالات</h2>
              <div className="row">
                {latestArticles.map(article => (
                  <div key={article.id} className="col-12 mb-4">
                    <ArticleCard article={article} />
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="col-12 col-md-4">
            <div className="sticky-top" style={{ top: '20px' }}>
              {/* Categories Widget */}
              <CategoryList />

              {/* About Widget */}
              <div className="card mt-4">
                <h3 className="section-title">عن الموقع</h3>
                <p>
                  موقع أوّاب للفتاوى والمقالات الإسلامية يهدف إلى نشر العلم الشرعي الصحيح وتقديم الفتاوى والمقالات الإسلامية الموثوقة.
                </p>
                <div className="text-center mt-3">
                  <a href="/about" className="btn btn-primary">المزيد عنا</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;

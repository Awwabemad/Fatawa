const mongoose = require('mongoose');

const FatwaRequestSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'الرجاء تحديد المستخدم']
  },
  question: {
    type: String,
    required: [true, 'الرجاء إدخال نص السؤال'],
    trim: true
  },
  status: {
    type: String,
    enum: ['pending', 'answered', 'rejected'],
    default: 'pending'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  fatwaId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Fatwa',
    default: null
  },
  rejectionReason: {
    type: String,
    trim: true
  }
});

module.exports = mongoose.model('FatwaRequest', FatwaRequestSchema);

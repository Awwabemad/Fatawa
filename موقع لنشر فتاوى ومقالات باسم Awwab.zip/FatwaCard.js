import React from 'react';
import { Link } from 'react-router-dom';

const FatwaCard = ({ fatwa }) => {
  // Default values if fatwa object is incomplete
  const {
    id = '1',
    title = 'عنوان الفتوى',
    question = 'نص السؤال يظهر هنا...',
    scholar = 'اسم المفتي',
    date = 'تاريخ النشر',
    category = 'التصنيف'
  } = fatwa || {};

  return (
    <div className="card fatwa-card">
      <h3 className="mb-3">
        <Link to={`/fatwas/${id}`}>{title}</Link>
      </h3>
      <div className="fatwa-question mb-3">
        {question.length > 150 ? `${question.substring(0, 150)}...` : question}
      </div>
      <div className="fatwa-meta">
        <span className="mr-3">
          <i className="fas fa-user-tie ml-1"></i> {scholar}
        </span>
        <span className="mr-3">
          <i className="far fa-calendar-alt ml-1"></i> {date}
        </span>
        <span>
          <i className="fas fa-folder ml-1"></i> {category}
        </span>
      </div>
      <div className="mt-3">
        <Link to={`/fatwas/${id}`} className="btn btn-primary">
          قراءة المزيد
        </Link>
      </div>
    </div>
  );
};

export default FatwaCard;

const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Tag = require('../models/Tag');

// @desc    Get all tags
// @route   GET /api/v1/tags
// @access  Public
exports.getTags = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

// @desc    Get single tag
// @route   GET /api/v1/tags/:id
// @access  Public
exports.getTag = asyncHandler(async (req, res, next) => {
  const tag = await Tag.findById(req.params.id);

  if (!tag) {
    return next(
      new ErrorResponse(`لا يوجد وسم بهذا المعرف ${req.params.id}`, 404)
    );
  }

  res.status(200).json({
    success: true,
    data: tag
  });
});

// @desc    Create new tag
// @route   POST /api/v1/tags
// @access  Private (Admin)
exports.createTag = asyncHandler(async (req, res, next) => {
  // Check if user is admin
  if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بإضافة وسوم`,
        403
      )
    );
  }

  const tag = await Tag.create(req.body);

  res.status(201).json({
    success: true,
    data: tag
  });
});

// @desc    Update tag
// @route   PUT /api/v1/tags/:id
// @access  Private (Admin)
exports.updateTag = asyncHandler(async (req, res, next) => {
  // Check if user is admin
  if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بتحديث الوسوم`,
        403
      )
    );
  }

  let tag = await Tag.findById(req.params.id);

  if (!tag) {
    return next(
      new ErrorResponse(`لا يوجد وسم بهذا المعرف ${req.params.id}`, 404)
    );
  }

  tag = await Tag.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: tag
  });
});

// @desc    Delete tag
// @route   DELETE /api/v1/tags/:id
// @access  Private (Admin)
exports.deleteTag = asyncHandler(async (req, res, next) => {
  // Check if user is admin
  if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بحذف الوسوم`,
        403
      )
    );
  }

  const tag = await Tag.findById(req.params.id);

  if (!tag) {
    return next(
      new ErrorResponse(`لا يوجد وسم بهذا المعرف ${req.params.id}`, 404)
    );
  }

  await tag.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

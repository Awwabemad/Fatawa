import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const FatwasList = () => {
  const [fatwas, setFatwas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Mock data for demonstration
  useEffect(() => {
    // In a real application, this would fetch data from the backend API
    const mockFatwas = [
      {
        _id: '1',
        title: 'حكم صيام الست من شوال',
        question: 'ما حكم صيام الست من شوال؟ وهل يجب أن تكون متتابعة؟',
        status: 'published',
        scholarId: {
          _id: '101',
          fullName: 'الشيخ أحمد'
        },
        createdAt: '2025-03-15T10:30:00',
        publishedAt: '2025-03-20T14:45:00',
        viewsCount: 1250,
        featured: true
      },
      {
        _id: '2',
        title: 'زكاة المال المستثمر في الأسهم',
        question: 'كيف تحسب زكاة المال المستثمر في الأسهم؟',
        status: 'published',
        scholarId: {
          _id: '102',
          fullName: 'الشيخ محمد'
        },
        createdAt: '2025-03-10T09:15:00',
        publishedAt: '2025-03-18T11:30:00',
        viewsCount: 980,
        featured: false
      },
      {
        _id: '3',
        title: 'حكم استخدام وسائل التواصل الاجتماعي',
        question: 'ما حكم استخدام وسائل التواصل الاجتماعي للدعوة إلى الله؟',
        status: 'draft',
        scholarId: {
          _id: '103',
          fullName: 'الشيخ عبدالله'
        },
        createdAt: '2025-04-01T16:45:00',
        publishedAt: null,
        viewsCount: 0,
        featured: false
      },
      {
        _id: '4',
        title: 'حكم صلاة التراويح في المنزل',
        question: 'هل يجوز صلاة التراويح في المنزل بدلاً من المسجد؟',
        status: 'published',
        scholarId: {
          _id: '101',
          fullName: 'الشيخ أحمد'
        },
        createdAt: '2025-03-25T13:20:00',
        publishedAt: '2025-03-28T10:15:00',
        viewsCount: 1560,
        featured: true
      },
      {
        _id: '5',
        title: 'حكم التبرع بالأعضاء',
        question: 'ما حكم التبرع بالأعضاء بعد الوفاة؟',
        status: 'archived',
        scholarId: {
          _id: '102',
          fullName: 'الشيخ محمد'
        },
        createdAt: '2025-02-10T11:30:00',
        publishedAt: '2025-02-15T09:45:00',
        viewsCount: 2100,
        featured: false
      }
    ];

    // Filter fatwas based on status filter
    let filteredFatwas = [...mockFatwas];
    if (filter !== 'all') {
      filteredFatwas = mockFatwas.filter(fatwa => fatwa.status === filter);
    }

    // Filter by search term
    if (searchTerm) {
      filteredFatwas = filteredFatwas.filter(
        fatwa => 
          fatwa.title.includes(searchTerm) || 
          fatwa.question.includes(searchTerm)
      );
    }

    setFatwas(filteredFatwas);
    setTotalPages(Math.ceil(filteredFatwas.length / 10));
    setLoading(false);
  }, [filter, searchTerm]);

  // Format date to Arabic format
  const formatDate = (dateString) => {
    if (!dateString) return 'غير منشور';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Get status badge
  const getStatusBadge = (status) => {
    switch (status) {
      case 'published':
        return <span className="badge bg-success">منشور</span>;
      case 'draft':
        return <span className="badge bg-warning">مسودة</span>;
      case 'archived':
        return <span className="badge bg-secondary">مؤرشف</span>;
      default:
        return <span className="badge bg-info">غير معروف</span>;
    }
  };

  const handleFilterChange = (e) => {
    setFilter(e.target.value);
    setCurrentPage(1);
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    // Search is already handled by the useEffect
  };

  return (
    <div className="container-fluid mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1>إدارة الفتاوى</h1>
        <Link to="/admin/fatwas/new" className="btn btn-primary">
          <i className="fas fa-plus-circle me-2"></i>
          إضافة فتوى جديدة
        </Link>
      </div>
      
      <div className="card mb-4">
        <div className="card-body">
          <div className="row">
            <div className="col-md-6">
              <form onSubmit={handleSearchSubmit}>
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="البحث في الفتاوى..."
                    value={searchTerm}
                    onChange={handleSearchChange}
                  />
                  <button className="btn btn-outline-secondary" type="submit">
                    <i className="fas fa-search"></i>
                  </button>
                </div>
              </form>
            </div>
            <div className="col-md-6">
              <div className="d-flex justify-content-end">
                <select
                  className="form-select w-auto"
                  value={filter}
                  onChange={handleFilterChange}
                >
                  <option value="all">جميع الفتاوى</option>
                  <option value="published">المنشورة</option>
                  <option value="draft">المسودات</option>
                  <option value="archived">المؤرشفة</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {loading ? (
        <div className="text-center my-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">جاري التحميل...</span>
          </div>
          <p className="mt-2">جاري تحميل الفتاوى...</p>
        </div>
      ) : (
        <>
          <div className="table-responsive">
            <table className="table table-striped table-hover">
              <thead className="table-light">
                <tr>
                  <th>العنوان</th>
                  <th>المفتي</th>
                  <th>تاريخ النشر</th>
                  <th>المشاهدات</th>
                  <th>الحالة</th>
                  <th>مميزة</th>
                  <th>الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {fatwas.length > 0 ? (
                  fatwas.map(fatwa => (
                    <tr key={fatwa._id}>
                      <td>
                        <Link to={`/admin/fatwas/${fatwa._id}`} className="text-decoration-none">
                          {fatwa.title}
                        </Link>
                      </td>
                      <td>{fatwa.scholarId.fullName}</td>
                      <td>{formatDate(fatwa.publishedAt)}</td>
                      <td>{fatwa.viewsCount}</td>
                      <td>{getStatusBadge(fatwa.status)}</td>
                      <td>
                        {fatwa.featured ? (
                          <i className="fas fa-star text-warning"></i>
                        ) : (
                          <i className="far fa-star text-muted"></i>
                        )}
                      </td>
                      <td>
                        <div className="btn-group btn-group-sm">
                          <Link to={`/admin/fatwas/${fatwa._id}/edit`} className="btn btn-outline-primary">
                            <i className="fas fa-edit"></i>
                          </Link>
                          <button className="btn btn-outline-danger">
                            <i className="fas fa-trash-alt"></i>
                          </button>
                          {fatwa.status === 'draft' && (
                            <button className="btn btn-outline-success">
                              <i className="fas fa-check-circle"></i>
                            </button>
                          )}
                          {fatwa.status === 'published' && !fatwa.featured && (
                            <button className="btn btn-outline-warning">
                              <i className="fas fa-star"></i>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7" className="text-center py-4">
                      لا توجد فتاوى متطابقة مع معايير البحث
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          {totalPages > 1 && (
            <nav aria-label="Page navigation" className="mt-4">
              <ul className="pagination justify-content-center">
                <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                  <button
                    className="page-link"
                    onClick={() => setCurrentPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    السابق
                  </button>
                </li>
                
                {[...Array(totalPages)].map((_, index) => (
                  <li
                    key={index}
                    className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}
                  >
                    <button
                      className="page-link"
                      onClick={() => setCurrentPage(index + 1)}
                    >
                      {index + 1}
                    </button>
                  </li>
                ))}
                
                <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                  <button
                    className="page-link"
                    onClick={() => setCurrentPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    التالي
                  </button>
                </li>
              </ul>
            </nav>
          )}
        </>
      )}
    </div>
  );
};

export default FatwasList;

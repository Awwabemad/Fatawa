import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="navbar">
      <div className="container navbar-container">
        <Link to="/" className="navbar-logo">أوّاب</Link>
        
        <button className="navbar-toggle" onClick={toggleMenu}>
          <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'}`}></i>
        </button>
        
        <ul className={`navbar-nav ${isMenuOpen ? 'show' : ''}`}>
          <li className="nav-item">
            <NavLink to="/" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>
              الرئيسية
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/fatwas" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>
              الفتاوى
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/articles" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>
              المقالات
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/login" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>
              تسجيل الدخول
            </NavLink>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;

import React from 'react';
import { useParams, Link } from 'react-router-dom';
import CategoryList from '../components/common/CategoryList';

const FatwaDetails = () => {
  const { id } = useParams();
  
  // Mock fatwa data (in a real app, this would be fetched from an API)
  const fatwa = {
    id: id,
    title: 'حكم صلاة التراويح في المنزل',
    question: 'ما حكم صلاة التراويح في المنزل بدلاً من المسجد؟ وهل يجوز أن أصليها منفرداً؟',
    answer: `الحمد لله والصلاة والسلام على رسول الله وعلى آله وصحبه، أما بعد:

فصلاة التراويح سنة مؤكدة، وهي من شعائر شهر رمضان المبارك، وقد ثبت أن النبي صلى الله عليه وسلم صلاها بأصحابه جماعة في المسجد ليالي، ثم تركها خشية أن تفرض عليهم.

والأفضل أن تصلى في المسجد جماعة، لما فيها من إظهار شعائر الإسلام، وإحياء المساجد، والاجتماع على الخير، وتعليم الجاهل، وتذكير الغافل.

ومع ذلك، فإن صلاة التراويح في البيت جائزة، سواء كان ذلك منفرداً أو جماعة مع أهل البيت، وليس في ذلك حرج، خاصة إذا كان هناك عذر يمنع من الذهاب إلى المسجد، كالمرض أو البعد عن المسجد أو غير ذلك من الأعذار.

وقد ثبت عن عمر بن الخطاب رضي الله عنه أنه قال: "والذي تنامون عنها أفضل من التي تقومون" يعني: صلاة آخر الليل أفضل من صلاة أوله، وهذا يدل على جواز صلاة التراويح في البيت.

والخلاصة: أن صلاة التراويح في المسجد جماعة أفضل، ولكن صلاتها في البيت جائزة، سواء كان ذلك منفرداً أو جماعة مع أهل البيت.

والله أعلم.`,
    scholar: 'الشيخ عبد الله بن محمد',
    date: '15 رمضان 1445',
    category: 'العبادات',
    views: 1250,
    relatedFatwas: [
      { id: 2, title: 'حكم قضاء صلاة التراويح' },
      { id: 3, title: 'عدد ركعات صلاة التراويح' },
      { id: 4, title: 'وقت صلاة التراويح' }
    ]
  };

  return (
    <div className="container mt-5">
      <div className="row">
        {/* Main Content Area */}
        <div className="col-12 col-md-8">
          <div className="card">
            {/* Fatwa Title */}
            <h1 className="mb-4">{fatwa.title}</h1>
            
            {/* Fatwa Meta */}
            <div className="fatwa-meta mb-4">
              <span className="mr-3">
                <i className="fas fa-user-tie ml-1"></i> {fatwa.scholar}
              </span>
              <span className="mr-3">
                <i className="far fa-calendar-alt ml-1"></i> {fatwa.date}
              </span>
              <span className="mr-3">
                <i className="fas fa-folder ml-1"></i> {fatwa.category}
              </span>
              <span>
                <i className="fas fa-eye ml-1"></i> {fatwa.views} مشاهدة
              </span>
            </div>
            
            {/* Question */}
            <div className="fatwa-question mb-4">
              <h3 className="mb-2">السؤال:</h3>
              <p>{fatwa.question}</p>
            </div>
            
            {/* Answer */}
            <div className="fatwa-answer mb-4">
              <h3 className="mb-2">الإجابة:</h3>
              <div style={{ whiteSpace: 'pre-line' }}>{fatwa.answer}</div>
            </div>
            
            {/* Share Buttons */}
            <div className="share-buttons mb-4">
              <h3 className="mb-2">مشاركة:</h3>
              <button className="btn btn-outline-primary ml-2">
                <i className="fab fa-facebook-f ml-1"></i> فيسبوك
              </button>
              <button className="btn btn-outline-info ml-2">
                <i className="fab fa-twitter ml-1"></i> تويتر
              </button>
              <button className="btn btn-outline-success ml-2">
                <i className="fab fa-whatsapp ml-1"></i> واتساب
              </button>
              <button className="btn btn-outline-secondary">
                <i className="fas fa-print ml-1"></i> طباعة
              </button>
            </div>
            
            {/* Related Fatwas */}
            <div className="related-fatwas">
              <h3 className="mb-3">فتاوى ذات صلة:</h3>
              <ul className="list-unstyled">
                {fatwa.relatedFatwas.map(related => (
                  <li key={related.id} className="mb-2">
                    <Link to={`/fatwas/${related.id}`}>
                      <i className="fas fa-chevron-left ml-2"></i>
                      {related.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
        
        {/* Sidebar */}
        <div className="col-12 col-md-4">
          <div className="sticky-top" style={{ top: '20px' }}>
            {/* Ask Fatwa Widget */}
            <div className="card mb-4">
              <h3 className="section-title">اسأل سؤالك</h3>
              <p>
                هل لديك سؤال شرعي؟ يمكنك إرسال سؤالك وسيتم الإجابة عليه من قبل علمائنا المختصين.
              </p>
              <div className="text-center mt-3">
                <a href="/ask-fatwa" className="btn btn-primary">اسأل الآن</a>
              </div>
            </div>
            
            {/* Categories Widget */}
            <CategoryList />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FatwaDetails;

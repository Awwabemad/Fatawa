const mongoose = require('mongoose');

const FavoriteSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'الرجاء تحديد المستخدم']
  },
  itemId: {
    type: mongoose.Schema.Types.ObjectId,
    required: [true, 'الرجاء تحديد العنصر']
  },
  itemType: {
    type: String,
    enum: ['fatwa', 'article'],
    required: [true, 'الرجاء تحديد نوع العنصر']
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Compound index to ensure a user can only favorite an item once
FavoriteSchema.index({ userId: 1, itemId: 1, itemType: 1 }, { unique: true });

module.exports = mongoose.model('Favorite', FavoriteSchema);

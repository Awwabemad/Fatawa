import React from 'react';
import { Link } from 'react-router-dom';

const ArticleCard = ({ article }) => {
  // Default values if article object is incomplete
  const {
    id = '1',
    title = 'عنوان المقال',
    content = 'محتوى المقال يظهر هنا...',
    author = 'اسم الكاتب',
    date = 'تاريخ النشر',
    category = 'التصنيف',
    thumbnail = null
  } = article || {};

  return (
    <div className="card article-card">
      {thumbnail && (
        <div className="article-thumbnail mb-3">
          <img src={thumbnail} alt={title} className="img-fluid" />
        </div>
      )}
      <h3 className="mb-3">
        <Link to={`/articles/${id}`}>{title}</Link>
      </h3>
      <div className="article-excerpt mb-3">
        {content.length > 150 ? `${content.substring(0, 150)}...` : content}
      </div>
      <div className="article-meta">
        <span className="mr-3">
          <i className="fas fa-user ml-1"></i> {author}
        </span>
        <span className="mr-3">
          <i className="far fa-calendar-alt ml-1"></i> {date}
        </span>
        <span>
          <i className="fas fa-folder ml-1"></i> {category}
        </span>
      </div>
      <div className="mt-3">
        <Link to={`/articles/${id}`} className="btn btn-primary">
          قراءة المزيد
        </Link>
      </div>
    </div>
  );
};

export default ArticleCard;

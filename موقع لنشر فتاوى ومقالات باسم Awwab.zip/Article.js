const mongoose = require('mongoose');

const ArticleSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'الرجاء إدخال عنوان المقال'],
    trim: true,
    maxlength: [200, 'عنوان المقال لا يمكن أن يتجاوز 200 حرف']
  },
  content: {
    type: String,
    required: [true, 'الرجاء إدخال محتوى المقال'],
    trim: true
  },
  authorId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'الرجاء تحديد الكاتب']
  },
  status: {
    type: String,
    enum: ['draft', 'published', 'archived'],
    default: 'draft'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  publishedAt: {
    type: Date
  },
  viewsCount: {
    type: Number,
    default: 0
  },
  featured: {
    type: Boolean,
    default: false
  },
  thumbnailImage: {
    type: String
  },
  categories: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category'
  }],
  tags: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tag'
  }],
  slug: {
    type: String,
    unique: true
  }
});

// Create slug from title before saving
ArticleSchema.pre('save', function(next) {
  // Create slug from title
  if (!this.slug) {
    this.slug = this.title
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^\u0621-\u064A\u0660-\u0669a-z0-9-]/g, '');
  }
  
  // Set published date if status is changed to published
  if (this.isModified('status') && this.status === 'published' && !this.publishedAt) {
    this.publishedAt = Date.now();
  }
  
  next();
});

module.exports = mongoose.model('Article', ArticleSchema);

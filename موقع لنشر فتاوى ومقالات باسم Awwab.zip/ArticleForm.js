import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const ArticleForm = ({ initialData = {}, isEditing = false }) => {
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    title: initialData.title || '',
    content: initialData.content || '',
    thumbnailImage: initialData.thumbnailImage || '',
    categories: initialData.categories || [],
    tags: initialData.tags || [],
    status: initialData.status || 'draft',
    featured: initialData.featured || false
  });

  const [availableCategories, setAvailableCategories] = useState([
    { _id: '1', name: 'العقيدة' },
    { _id: '2', name: 'العبادات' },
    { _id: '3', name: 'المعاملات' },
    { _id: '4', name: 'الأسرة' },
    { _id: '5', name: 'الأخلاق' }
  ]);

  const [availableTags, setAvailableTags] = useState([
    { _id: '1', name: 'رمضان' },
    { _id: '2', name: 'الصلاة' },
    { _id: '3', name: 'الزكاة' },
    { _id: '4', name: 'الحج' },
    { _id: '5', name: 'الصيام' }
  ]);

  const { title, content, thumbnailImage, categories, tags, status, featured } = formData;

  const onChange = e => {
    const { name, value, checked, type } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const onCategoryChange = e => {
    const categoryId = e.target.value;
    const isChecked = e.target.checked;
    
    if (isChecked) {
      // Add category
      setFormData({
        ...formData,
        categories: [...categories, categoryId]
      });
    } else {
      // Remove category
      setFormData({
        ...formData,
        categories: categories.filter(id => id !== categoryId)
      });
    }
  };

  const onTagChange = e => {
    const tagId = e.target.value;
    const isChecked = e.target.checked;
    
    if (isChecked) {
      // Add tag
      setFormData({
        ...formData,
        tags: [...tags, tagId]
      });
    } else {
      // Remove tag
      setFormData({
        ...formData,
        tags: tags.filter(id => id !== tagId)
      });
    }
  };

  const onSubmit = e => {
    e.preventDefault();
    
    // In a real application, this would send data to the backend
    console.log('Form submitted', formData);
    
    // Navigate back to articles list
    navigate('/admin/articles');
  };

  return (
    <div className="card">
      <div className="card-body">
        <h2 className="card-title mb-4">
          {isEditing ? 'تعديل مقال' : 'إضافة مقال جديد'}
        </h2>
        
        <form onSubmit={onSubmit}>
          <div className="form-group mb-3">
            <label htmlFor="title">عنوان المقال</label>
            <input
              type="text"
              className="form-control"
              id="title"
              name="title"
              value={title}
              onChange={onChange}
              required
            />
          </div>
          
          <div className="form-group mb-3">
            <label htmlFor="thumbnailImage">رابط الصورة المصغرة</label>
            <input
              type="text"
              className="form-control"
              id="thumbnailImage"
              name="thumbnailImage"
              value={thumbnailImage}
              onChange={onChange}
              placeholder="https://example.com/image.jpg"
            />
            <small className="form-text text-muted">
              أدخل رابط الصورة المصغرة للمقال (اختياري)
            </small>
          </div>
          
          <div className="form-group mb-3">
            <label htmlFor="content">محتوى المقال</label>
            <textarea
              className="form-control"
              id="content"
              name="content"
              rows="15"
              value={content}
              onChange={onChange}
              required
            ></textarea>
          </div>
          
          <div className="form-group mb-3">
            <label>التصنيفات</label>
            <div className="row">
              {availableCategories.map(category => (
                <div className="col-md-4" key={category._id}>
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={`category-${category._id}`}
                      value={category._id}
                      checked={categories.includes(category._id)}
                      onChange={onCategoryChange}
                    />
                    <label className="form-check-label" htmlFor={`category-${category._id}`}>
                      {category.name}
                    </label>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="form-group mb-3">
            <label>الوسوم</label>
            <div className="row">
              {availableTags.map(tag => (
                <div className="col-md-4" key={tag._id}>
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={`tag-${tag._id}`}
                      value={tag._id}
                      checked={tags.includes(tag._id)}
                      onChange={onTagChange}
                    />
                    <label className="form-check-label" htmlFor={`tag-${tag._id}`}>
                      {tag.name}
                    </label>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="form-group mb-3">
            <label htmlFor="status">الحالة</label>
            <select
              className="form-control"
              id="status"
              name="status"
              value={status}
              onChange={onChange}
            >
              <option value="draft">مسودة</option>
              <option value="published">منشور</option>
              <option value="archived">مؤرشف</option>
            </select>
          </div>
          
          <div className="form-group mb-4">
            <div className="form-check">
              <input
                className="form-check-input"
                type="checkbox"
                id="featured"
                name="featured"
                checked={featured}
                onChange={onChange}
              />
              <label className="form-check-label" htmlFor="featured">
                مقال مميز
              </label>
            </div>
          </div>
          
          <div className="d-flex justify-content-between">
            <button type="submit" className="btn btn-primary">
              {isEditing ? 'تحديث المقال' : 'إضافة المقال'}
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => navigate('/admin/articles')}
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ArticleForm;

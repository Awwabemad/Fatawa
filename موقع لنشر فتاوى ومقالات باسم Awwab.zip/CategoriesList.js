import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const CategoriesList = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Mock data for demonstration
  useEffect(() => {
    setLoading(true);
    
    // In a real application, this would fetch data from the backend API
    setTimeout(() => {
      // Mock categories data with content counts
      const mockCategories = [
        { 
          _id: '1', 
          name: 'العقيدة', 
          slug: 'aqeedah',
          description: 'تصنيف يشمل الفتاوى والمقالات المتعلقة بأصول الإيمان وأركانه، والتوحيد وأنواعه، وما يتعلق بالعقيدة الإسلامية الصحيحة.',
          icon: 'fa-star',
          color: 'primary',
          counts: {
            fatwas: 15,
            articles: 8
          }
        },
        { 
          _id: '2', 
          name: 'العبادات', 
          slug: 'worship',
          description: 'تصنيف يشمل الفتاوى والمقالات المتعلقة بالصلاة والصيام والزكاة والحج وغيرها من العبادات التي يتقرب بها المسلم إلى الله تعالى.',
          icon: 'fa-pray',
          color: 'success',
          counts: {
            fatwas: 42,
            articles: 23
          }
        },
        { 
          _id: '3', 
          name: 'المعاملات', 
          slug: 'transactions',
          description: 'تصنيف يشمل الفتاوى والمقالات المتعلقة بالبيع والشراء والإجارة والشركات والمعاملات المالية المعاصرة وغيرها.',
          icon: 'fa-handshake',
          color: 'info',
          counts: {
            fatwas: 28,
            articles: 15
          }
        },
        { 
          _id: '4', 
          name: 'الأسرة', 
          slug: 'family',
          description: 'تصنيف يشمل الفتاوى والمقالات المتعلقة بالزواج والطلاق والحضانة والنفقة وتربية الأبناء وغيرها من أحكام الأسرة.',
          icon: 'fa-users',
          color: 'warning',
          counts: {
            fatwas: 35,
            articles: 19
          }
        },
        { 
          _id: '5', 
          name: 'الأخلاق', 
          slug: 'ethics',
          description: 'تصنيف يشمل الفتاوى والمقالات المتعلقة بالأخلاق الإسلامية والآداب الشرعية والسلوك القويم الذي ينبغي أن يتحلى به المسلم.',
          icon: 'fa-heart',
          color: 'danger',
          counts: {
            fatwas: 20,
            articles: 27
          }
        },
        { 
          _id: '6', 
          name: 'السيرة النبوية', 
          slug: 'seerah',
          description: 'تصنيف يشمل الفتاوى والمقالات المتعلقة بسيرة النبي محمد صلى الله عليه وسلم وحياته وغزواته وشمائله.',
          icon: 'fa-mosque',
          color: 'secondary',
          counts: {
            fatwas: 12,
            articles: 31
          }
        }
      ];
      
      setCategories(mockCategories);
      setLoading(false);
    }, 1000);
  }, []);
  
  return (
    <div className="container mt-5">
      <div className="row mb-4">
        <div className="col-12">
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><Link to="/">الرئيسية</Link></li>
              <li className="breadcrumb-item active" aria-current="page">التصنيفات</li>
            </ol>
          </nav>
          
          <h1 className="mb-4">تصنيفات المحتوى</h1>
          
          {loading ? (
            <div className="text-center my-5">
              <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">جاري التحميل...</span>
              </div>
              <p className="mt-2">جاري تحميل التصنيفات...</p>
            </div>
          ) : (
            <div className="row">
              {categories.map(category => (
                <div key={category._id} className="col-md-6 col-lg-4 mb-4">
                  <div className="card h-100 border-light shadow-sm">
                    <div className="card-body">
                      <div className="d-flex align-items-center mb-3">
                        <div className={`category-icon bg-${category.color} text-white me-3`}>
                          <i className={`fas ${category.icon}`}></i>
                        </div>
                        <h3 className="card-title mb-0">
                          <Link to={`/categories/${category.slug}`} className="text-decoration-none">
                            {category.name}
                          </Link>
                        </h3>
                      </div>
                      <p className="card-text text-muted">
                        {category.description.length > 120 
                          ? `${category.description.substring(0, 120)}...` 
                          : category.description}
                      </p>
                    </div>
                    <div className="card-footer bg-white border-top-0">
                      <div className="d-flex justify-content-between align-items-center">
                        <div>
                          <span className="badge bg-primary me-2">
                            <i className="fas fa-scroll me-1"></i>
                            {category.counts.fatwas} فتوى
                          </span>
                          <span className="badge bg-success">
                            <i className="fas fa-newspaper me-1"></i>
                            {category.counts.articles} مقال
                          </span>
                        </div>
                        <Link to={`/categories/${category.slug}`} className="btn btn-sm btn-outline-primary">
                          تصفح المحتوى
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CategoriesList;

const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Article = require('../models/Article');
const User = require('../models/User');

// @desc    Get all articles
// @route   GET /api/v1/articles
// @access  Public
exports.getArticles = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

// @desc    Get single article
// @route   GET /api/v1/articles/:id
// @access  Public
exports.getArticle = asyncHandler(async (req, res, next) => {
  const article = await Article.findById(req.params.id)
    .populate({
      path: 'authorId',
      select: 'fullName username profileImage'
    })
    .populate('categories')
    .populate('tags');

  if (!article) {
    return next(
      new ErrorResponse(`لا يوجد مقال بهذا المعرف ${req.params.id}`, 404)
    );
  }

  // Increment views count
  article.viewsCount += 1;
  await article.save({ validateBeforeSave: false });

  res.status(200).json({
    success: true,
    data: article
  });
});

// @desc    Create new article
// @route   POST /api/v1/articles
// @access  Private (Admin/Scholar)
exports.createArticle = asyncHandler(async (req, res, next) => {
  // Add author to req.body
  req.body.authorId = req.user.id;

  // Check if user is scholar or admin
  if (req.user.role !== 'scholar' && req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بإضافة مقالات`,
        403
      )
    );
  }

  const article = await Article.create(req.body);

  res.status(201).json({
    success: true,
    data: article
  });
});

// @desc    Update article
// @route   PUT /api/v1/articles/:id
// @access  Private (Admin/Scholar)
exports.updateArticle = asyncHandler(async (req, res, next) => {
  let article = await Article.findById(req.params.id);

  if (!article) {
    return next(
      new ErrorResponse(`لا يوجد مقال بهذا المعرف ${req.params.id}`, 404)
    );
  }

  // Make sure user is article author or admin
  if (
    article.authorId.toString() !== req.user.id &&
    req.user.role !== 'admin' &&
    req.user.role !== 'super_admin'
  ) {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بتحديث هذا المقال`,
        403
      )
    );
  }

  article = await Article.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: article
  });
});

// @desc    Delete article
// @route   DELETE /api/v1/articles/:id
// @access  Private (Admin/Scholar)
exports.deleteArticle = asyncHandler(async (req, res, next) => {
  const article = await Article.findById(req.params.id);

  if (!article) {
    return next(
      new ErrorResponse(`لا يوجد مقال بهذا المعرف ${req.params.id}`, 404)
    );
  }

  // Make sure user is article author or admin
  if (
    article.authorId.toString() !== req.user.id &&
    req.user.role !== 'admin' &&
    req.user.role !== 'super_admin'
  ) {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بحذف هذا المقال`,
        403
      )
    );
  }

  await article.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Get featured articles
// @route   GET /api/v1/articles/featured
// @access  Public
exports.getFeaturedArticles = asyncHandler(async (req, res, next) => {
  const articles = await Article.find({ featured: true, status: 'published' })
    .populate({
      path: 'authorId',
      select: 'fullName username profileImage'
    })
    .populate('categories')
    .limit(5);

  res.status(200).json({
    success: true,
    count: articles.length,
    data: articles
  });
});

// @desc    Get latest articles
// @route   GET /api/v1/articles/latest
// @access  Public
exports.getLatestArticles = asyncHandler(async (req, res, next) => {
  const articles = await Article.find({ status: 'published' })
    .populate({
      path: 'authorId',
      select: 'fullName username profileImage'
    })
    .populate('categories')
    .sort({ publishedAt: -1 })
    .limit(5);

  res.status(200).json({
    success: true,
    count: articles.length,
    data: articles
  });
});

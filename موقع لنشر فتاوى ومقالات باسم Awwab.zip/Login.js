import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });

  const { email, password, rememberMe } = formData;

  const onChange = e => {
    const { name, value, checked, type } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const onSubmit = e => {
    e.preventDefault();
    // Login logic would go here in a real application
    console.log('Login form submitted', formData);
  };

  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-md-6 mx-auto">
          <div className="card">
            <div className="card-body">
              <h1 className="text-center mb-4">تسجيل الدخول</h1>
              
              <form onSubmit={onSubmit}>
                <div className="form-group mb-3">
                  <label htmlFor="email">البريد الإلكتروني</label>
                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    name="email"
                    value={email}
                    onChange={onChange}
                    required
                  />
                </div>
                
                <div className="form-group mb-3">
                  <label htmlFor="password">كلمة المرور</label>
                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    name="password"
                    value={password}
                    onChange={onChange}
                    required
                  />
                </div>
                
                <div className="form-group mb-3">
                  <div className="form-check">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="rememberMe"
                      name="rememberMe"
                      checked={rememberMe}
                      onChange={onChange}
                    />
                    <label className="form-check-label" htmlFor="rememberMe">
                      تذكرني
                    </label>
                  </div>
                </div>
                
                <button type="submit" className="btn btn-primary btn-block w-100 mb-3">
                  تسجيل الدخول
                </button>
              </form>
              
              <div className="text-center mt-3">
                <Link to="/forgot-password">نسيت كلمة المرور؟</Link>
              </div>
              
              <hr />
              
              <div className="text-center">
                <p>ليس لديك حساب؟</p>
                <Link to="/register" className="btn btn-outline-primary">
                  إنشاء حساب جديد
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;

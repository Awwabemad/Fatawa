import React from 'react';
import { Link } from 'react-router-dom';

const CategoryList = ({ categories }) => {
  // Default categories if none provided
  const defaultCategories = [
    { id: 1, name: 'العقيدة', count: 24 },
    { id: 2, name: 'العبادات', count: 35 },
    { id: 3, name: 'المعاملات', count: 18 },
    { id: 4, name: 'الأسرة', count: 29 },
    { id: 5, name: 'الأخلاق', count: 15 }
  ];

  const categoriesToRender = categories || defaultCategories;

  return (
    <div className="category-list card">
      <h3 className="section-title">التصنيفات</h3>
      <ul className="list-unstyled">
        {categoriesToRender.map(category => (
          <li key={category.id} className="mb-2">
            <Link to={`/category/${category.id}`} className="d-flex justify-content-between align-items-center">
              <span>{category.name}</span>
              <span className="badge bg-light text-primary">{category.count}</span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CategoryList;

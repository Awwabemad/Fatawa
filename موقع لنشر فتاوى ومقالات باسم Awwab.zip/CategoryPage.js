import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';

const CategoryPage = () => {
  const { slug } = useParams();
  const [category, setCategory] = useState(null);
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  
  // Mock data for demonstration
  useEffect(() => {
    setLoading(true);
    
    // In a real application, this would fetch data from the backend API
    setTimeout(() => {
      // Mock category data
      const mockCategories = [
        { 
          _id: '1', 
          name: 'العقيدة', 
          slug: 'aqeedah',
          description: 'تصنيف يشمل الفتاوى والمقالات المتعلقة بأصول الإيمان وأركانه، والتوحيد وأنواعه، وما يتعلق بالعقيدة الإسلامية الصحيحة.'
        },
        { 
          _id: '2', 
          name: 'العبادات', 
          slug: 'worship',
          description: 'تصنيف يشمل الفتاوى والمقالات المتعلقة بالصلاة والصيام والزكاة والحج وغيرها من العبادات التي يتقرب بها المسلم إلى الله تعالى.'
        },
        { 
          _id: '3', 
          name: 'المعاملات', 
          slug: 'transactions',
          description: 'تصنيف يشمل الفتاوى والمقالات المتعلقة بالبيع والشراء والإجارة والشركات والمعاملات المالية المعاصرة وغيرها.'
        },
        { 
          _id: '4', 
          name: 'الأسرة', 
          slug: 'family',
          description: 'تصنيف يشمل الفتاوى والمقالات المتعلقة بالزواج والطلاق والحضانة والنفقة وتربية الأبناء وغيرها من أحكام الأسرة.'
        },
        { 
          _id: '5', 
          name: 'الأخلاق', 
          slug: 'ethics',
          description: 'تصنيف يشمل الفتاوى والمقالات المتعلقة بالأخلاق الإسلامية والآداب الشرعية والسلوك القويم الذي ينبغي أن يتحلى به المسلم.'
        }
      ];
      
      // Find the category by slug
      const foundCategory = mockCategories.find(cat => cat.slug === slug);
      setCategory(foundCategory);
      
      if (foundCategory) {
        // Mock content data
        const mockContent = [
          {
            _id: '1',
            title: 'حكم صيام الست من شوال',
            type: 'fatwa',
            excerpt: 'صيام ستة أيام من شوال بعد رمضان سنة مستحبة، وليست واجبة، ويجوز أن تكون متتابعة أو متفرقة...',
            date: '2025-03-20T14:45:00',
            category: { _id: '2', name: 'العبادات', slug: 'worship' },
            url: '/fatwas/1'
          },
          {
            _id: '2',
            title: 'زكاة المال المستثمر في الأسهم',
            type: 'fatwa',
            excerpt: 'تجب الزكاة في الأسهم المستثمرة للتجارة، وتحسب قيمتها السوقية يوم وجوب الزكاة...',
            date: '2025-03-18T11:30:00',
            category: { _id: '3', name: 'المعاملات', slug: 'transactions' },
            url: '/fatwas/2'
          },
          {
            _id: '3',
            title: 'فضل العشر الأواخر من رمضان',
            type: 'article',
            excerpt: 'العشر الأواخر من رمضان هي أفضل أيام الشهر الكريم، وفيها ليلة القدر التي هي خير من ألف شهر...',
            date: '2025-03-20T14:45:00',
            category: { _id: '2', name: 'العبادات', slug: 'worship' },
            url: '/articles/1'
          },
          {
            _id: '4',
            title: 'أثر الصيام في تهذيب النفس',
            type: 'article',
            excerpt: 'الصيام من أعظم العبادات التي تهذب النفس وتزكيها، وتقوي الإرادة وتعلم الصبر...',
            date: '2025-03-18T11:30:00',
            category: { _id: '5', name: 'الأخلاق', slug: 'ethics' },
            url: '/articles/2'
          },
          {
            _id: '5',
            title: 'حكم صلاة التراويح في المنزل',
            type: 'fatwa',
            excerpt: 'صلاة التراويح سنة مؤكدة، والأفضل أداؤها في المسجد جماعة، ولكن يجوز أداؤها في المنزل...',
            date: '2025-03-28T10:15:00',
            category: { _id: '2', name: 'العبادات', slug: 'worship' },
            url: '/fatwas/4'
          },
          {
            _id: '6',
            title: 'أهمية الصلاة في وقتها',
            type: 'article',
            excerpt: 'الصلاة عماد الدين، وهي أول ما يحاسب عليه العبد يوم القيامة، وأداؤها في وقتها من أحب الأعمال إلى الله...',
            date: '2025-03-15T09:30:00',
            category: { _id: '2', name: 'العبادات', slug: 'worship' },
            url: '/articles/3'
          },
          {
            _id: '7',
            title: 'حكم الجمع بين الصلاتين للمسافر',
            type: 'fatwa',
            excerpt: 'يجوز للمسافر الجمع بين الظهر والعصر، وبين المغرب والعشاء، تقديماً أو تأخيراً، للتخفيف عنه...',
            date: '2025-03-10T11:45:00',
            category: { _id: '2', name: 'العبادات', slug: 'worship' },
            url: '/fatwas/5'
          }
        ];
        
        // Filter content by category
        const filteredContent = mockContent.filter(item => item.category.slug === slug);
        setContent(filteredContent);
        setTotalPages(Math.ceil(filteredContent.length / 5));
      }
      
      setLoading(false);
    }, 1000);
  }, [slug]);
  
  // Format date to Arabic format
  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Filter content by type
  const filteredContent = activeTab === 'all' 
    ? content 
    : content.filter(item => item.type === activeTab);
  
  // Paginate content
  const itemsPerPage = 5;
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedContent = filteredContent.slice(startIndex, startIndex + itemsPerPage);
  
  return (
    <div className="container mt-5">
      {loading ? (
        <div className="text-center my-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">جاري التحميل...</span>
          </div>
          <p className="mt-2">جاري تحميل المحتوى...</p>
        </div>
      ) : category ? (
        <>
          <div className="row mb-4">
            <div className="col-12">
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item"><Link to="/">الرئيسية</Link></li>
                  <li className="breadcrumb-item"><Link to="/categories">التصنيفات</Link></li>
                  <li className="breadcrumb-item active" aria-current="page">{category.name}</li>
                </ol>
              </nav>
              
              <div className="category-header mb-4">
                <h1 className="mb-3">{category.name}</h1>
                <p className="lead">{category.description}</p>
              </div>
              
              <ul className="nav nav-tabs mb-4">
                <li className="nav-item">
                  <button 
                    className={`nav-link ${activeTab === 'all' ? 'active' : ''}`}
                    onClick={() => setActiveTab('all')}
                  >
                    الكل ({content.length})
                  </button>
                </li>
                <li className="nav-item">
                  <button 
                    className={`nav-link ${activeTab === 'fatwa' ? 'active' : ''}`}
                    onClick={() => setActiveTab('fatwa')}
                  >
                    الفتاوى ({content.filter(item => item.type === 'fatwa').length})
                  </button>
                </li>
                <li className="nav-item">
                  <button 
                    className={`nav-link ${activeTab === 'article' ? 'active' : ''}`}
                    onClick={() => setActiveTab('article')}
                  >
                    المقالات ({content.filter(item => item.type === 'article').length})
                  </button>
                </li>
              </ul>
              
              {filteredContent.length > 0 ? (
                <>
                  <div className="list-group">
                    {paginatedContent.map(item => (
                      <div key={`${item.type}-${item._id}`} className="list-group-item list-group-item-action">
                        <div className="d-flex w-100 justify-content-between align-items-center mb-2">
                          <h5 className="mb-0">
                            <Link to={item.url} className="text-decoration-none">
                              {item.title}
                            </Link>
                          </h5>
                          <span className={`badge bg-${item.type === 'fatwa' ? 'primary' : 'success'}`}>
                            {item.type === 'fatwa' ? 'فتوى' : 'مقال'}
                          </span>
                        </div>
                        <p className="mb-2">{item.excerpt}</p>
                        <small className="text-muted">{formatDate(item.date)}</small>
                      </div>
                    ))}
                  </div>
                  
                  {totalPages > 1 && (
                    <nav aria-label="Page navigation" className="mt-4">
                      <ul className="pagination justify-content-center">
                        <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                          <button
                            className="page-link"
                            onClick={() => setCurrentPage(currentPage - 1)}
                            disabled={currentPage === 1}
                          >
                            السابق
                          </button>
                        </li>
                        
                        {[...Array(totalPages)].map((_, index) => (
                          <li
                            key={index}
                            className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}
                          >
                            <button
                              className="page-link"
                              onClick={() => setCurrentPage(index + 1)}
                            >
                              {index + 1}
                            </button>
                          </li>
                        ))}
                        
                        <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                          <button
                            className="page-link"
                            onClick={() => setCurrentPage(currentPage + 1)}
                            disabled={currentPage === totalPages}
                          >
                            التالي
                          </button>
                        </li>
                      </ul>
                    </nav>
                  )}
                </>
              ) : (
                <div className="alert alert-info text-center" role="alert">
                  <i className="fas fa-info-circle me-2"></i>
                  لا يوجد محتوى في هذا التصنيف حالياً
                </div>
              )}
            </div>
          </div>
        </>
      ) : (
        <div className="alert alert-warning text-center" role="alert">
          <i className="fas fa-exclamation-triangle me-2"></i>
          التصنيف غير موجود
        </div>
      )}
    </div>
  );
};

export default CategoryPage;

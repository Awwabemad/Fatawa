const mongoose = require('mongoose');

const CommentSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'الرجاء تحديد المستخدم']
  },
  itemId: {
    type: mongoose.Schema.Types.ObjectId,
    required: [true, 'الرجاء تحديد العنصر']
  },
  itemType: {
    type: String,
    enum: ['fatwa', 'article'],
    required: [true, 'الرجاء تحديد نوع العنصر']
  },
  content: {
    type: String,
    required: [true, 'الرجاء إدخال محتوى التعليق'],
    trim: true,
    maxlength: [1000, 'محتوى التعليق لا يمكن أن يتجاوز 1000 حرف']
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending'
  },
  rejectionReason: {
    type: String,
    trim: true
  }
});

module.exports = mongoose.model('Comment', CommentSchema);

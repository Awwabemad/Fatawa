const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Fatwa = require('../models/Fatwa');
const User = require('../models/User');

// @desc    Get all fatwas
// @route   GET /api/v1/fatwas
// @access  Public
exports.getFatwas = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

// @desc    Get single fatwa
// @route   GET /api/v1/fatwas/:id
// @access  Public
exports.getFatwa = asyncHandler(async (req, res, next) => {
  const fatwa = await Fatwa.findById(req.params.id)
    .populate({
      path: 'scholarId',
      select: 'fullName username profileImage'
    })
    .populate('categories')
    .populate('tags');

  if (!fatwa) {
    return next(
      new ErrorResponse(`لا توجد فتوى بهذا المعرف ${req.params.id}`, 404)
    );
  }

  // Increment views count
  fatwa.viewsCount += 1;
  await fatwa.save({ validateBeforeSave: false });

  res.status(200).json({
    success: true,
    data: fatwa
  });
});

// @desc    Create new fatwa
// @route   POST /api/v1/fatwas
// @access  Private (Admin/Scholar)
exports.createFatwa = asyncHandler(async (req, res, next) => {
  // Add scholar to req.body
  req.body.scholarId = req.user.id;

  // Check if user is scholar or admin
  if (req.user.role !== 'scholar' && req.user.role !== 'admin' && req.user.role !== 'super_admin') {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بإضافة فتاوى`,
        403
      )
    );
  }

  const fatwa = await Fatwa.create(req.body);

  res.status(201).json({
    success: true,
    data: fatwa
  });
});

// @desc    Update fatwa
// @route   PUT /api/v1/fatwas/:id
// @access  Private (Admin/Scholar)
exports.updateFatwa = asyncHandler(async (req, res, next) => {
  let fatwa = await Fatwa.findById(req.params.id);

  if (!fatwa) {
    return next(
      new ErrorResponse(`لا توجد فتوى بهذا المعرف ${req.params.id}`, 404)
    );
  }

  // Make sure user is fatwa scholar or admin
  if (
    fatwa.scholarId.toString() !== req.user.id &&
    req.user.role !== 'admin' &&
    req.user.role !== 'super_admin'
  ) {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بتحديث هذه الفتوى`,
        403
      )
    );
  }

  fatwa = await Fatwa.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: fatwa
  });
});

// @desc    Delete fatwa
// @route   DELETE /api/v1/fatwas/:id
// @access  Private (Admin/Scholar)
exports.deleteFatwa = asyncHandler(async (req, res, next) => {
  const fatwa = await Fatwa.findById(req.params.id);

  if (!fatwa) {
    return next(
      new ErrorResponse(`لا توجد فتوى بهذا المعرف ${req.params.id}`, 404)
    );
  }

  // Make sure user is fatwa scholar or admin
  if (
    fatwa.scholarId.toString() !== req.user.id &&
    req.user.role !== 'admin' &&
    req.user.role !== 'super_admin'
  ) {
    return next(
      new ErrorResponse(
        `المستخدم ${req.user.id} غير مصرح له بحذف هذه الفتوى`,
        403
      )
    );
  }

  await fatwa.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Get featured fatwas
// @route   GET /api/v1/fatwas/featured
// @access  Public
exports.getFeaturedFatwas = asyncHandler(async (req, res, next) => {
  const fatwas = await Fatwa.find({ featured: true, status: 'published' })
    .populate({
      path: 'scholarId',
      select: 'fullName username profileImage'
    })
    .populate('categories')
    .limit(5);

  res.status(200).json({
    success: true,
    count: fatwas.length,
    data: fatwas
  });
});

// @desc    Get latest fatwas
// @route   GET /api/v1/fatwas/latest
// @access  Public
exports.getLatestFatwas = asyncHandler(async (req, res, next) => {
  const fatwas = await Fatwa.find({ status: 'published' })
    .populate({
      path: 'scholarId',
      select: 'fullName username profileImage'
    })
    .populate('categories')
    .sort({ publishedAt: -1 })
    .limit(5);

  res.status(200).json({
    success: true,
    count: fatwas.length,
    data: fatwas
  });
});

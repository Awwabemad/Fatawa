const mongoose = require('mongoose');

const CategorySchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'الرجاء إدخال اسم التصنيف'],
    unique: true,
    trim: true,
    maxlength: [50, 'اسم التصنيف لا يمكن أن يتجاوز 50 حرفاً']
  },
  slug: {
    type: String,
    unique: true,
    trim: true
  },
  parentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category',
    default: null
  },
  description: {
    type: String,
    maxlength: [500, 'وصف التصنيف لا يمكن أن يتجاوز 500 حرف']
  },
  type: {
    type: String,
    enum: ['fatwa', 'article', 'both'],
    default: 'both'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create slug from name before saving
CategorySchema.pre('save', function(next) {
  // Create slug from name
  this.slug = this.name
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^\u0621-\u064A\u0660-\u0669a-z0-9-]/g, '');
  
  next();
});

module.exports = mongoose.model('Category', CategorySchema);

import React from 'react';
import { Link } from 'react-router-dom';

const SearchBar = ({ placeholder = "ابحث في الفتاوى والمقالات..." }) => {
  return (
    <div className="search-bar">
      <input 
        type="text" 
        className="search-input" 
        placeholder={placeholder} 
      />
      <i className="fas fa-search search-icon"></i>
    </div>
  );
};

export default SearchBar;

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const TagsList = () => {
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Mock data for demonstration
  useEffect(() => {
    setLoading(true);
    
    // In a real application, this would fetch data from the backend API
    setTimeout(() => {
      // Mock tags data with content counts
      const mockTags = [
        { 
          _id: '1', 
          name: 'رمضان', 
          slug: 'ramadan',
          description: 'محتوى متعلق بشهر رمضان المبارك وأحكامه وفضائله',
          counts: {
            fatwas: 24,
            articles: 18
          }
        },
        { 
          _id: '2', 
          name: 'الصلاة', 
          slug: 'prayer',
          description: 'محتوى متعلق بالصلاة وأحكامها وفضائلها',
          counts: {
            fatwas: 35,
            articles: 15
          }
        },
        { 
          _id: '3', 
          name: 'الزكاة', 
          slug: 'zakat',
          description: 'محتوى متعلق بالزكاة وأحكامها ومصارفها',
          counts: {
            fatwas: 18,
            articles: 9
          }
        },
        { 
          _id: '4', 
          name: 'الحج', 
          slug: 'hajj',
          description: 'محتوى متعلق بالحج والعمرة وأحكامهما',
          counts: {
            fatwas: 22,
            articles: 14
          }
        },
        { 
          _id: '5', 
          name: 'الصيام', 
          slug: 'fasting',
          description: 'محتوى متعلق بالصيام وأحكامه وفضائله',
          counts: {
            fatwas: 20,
            articles: 12
          }
        },
        { 
          _id: '6', 
          name: 'الزواج', 
          slug: 'marriage',
          description: 'محتوى متعلق بالزواج وأحكامه وآدابه',
          counts: {
            fatwas: 28,
            articles: 16
          }
        },
        { 
          _id: '7', 
          name: 'الطلاق', 
          slug: 'divorce',
          description: 'محتوى متعلق بالطلاق وأحكامه',
          counts: {
            fatwas: 15,
            articles: 8
          }
        },
        { 
          _id: '8', 
          name: 'تربية الأبناء', 
          slug: 'parenting',
          description: 'محتوى متعلق بتربية الأبناء وفق المنهج الإسلامي',
          counts: {
            fatwas: 12,
            articles: 20
          }
        },
        { 
          _id: '9', 
          name: 'المعاملات المالية', 
          slug: 'financial-transactions',
          description: 'محتوى متعلق بالمعاملات المالية وأحكامها في الإسلام',
          counts: {
            fatwas: 25,
            articles: 13
          }
        },
        { 
          _id: '10', 
          name: 'الأخلاق', 
          slug: 'ethics',
          description: 'محتوى متعلق بالأخلاق الإسلامية وآداب السلوك',
          counts: {
            fatwas: 16,
            articles: 22
          }
        }
      ];
      
      setTags(mockTags);
      setLoading(false);
    }, 1000);
  }, []);
  
  // Sort tags by total content count (fatwas + articles)
  const sortedTags = [...tags].sort((a, b) => 
    (b.counts.fatwas + b.counts.articles) - (a.counts.fatwas + a.counts.articles)
  );
  
  // Get tag size class based on content count
  const getTagSizeClass = (tag) => {
    const totalCount = tag.counts.fatwas + tag.counts.articles;
    if (totalCount > 40) return 'fs-3';
    if (totalCount > 30) return 'fs-4';
    if (totalCount > 20) return 'fs-5';
    return 'fs-6';
  };
  
  return (
    <div className="container mt-5">
      <div className="row mb-4">
        <div className="col-12">
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><Link to="/">الرئيسية</Link></li>
              <li className="breadcrumb-item active" aria-current="page">الوسوم</li>
            </ol>
          </nav>
          
          <h1 className="mb-4">وسوم المحتوى</h1>
          
          {loading ? (
            <div className="text-center my-5">
              <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">جاري التحميل...</span>
              </div>
              <p className="mt-2">جاري تحميل الوسوم...</p>
            </div>
          ) : (
            <>
              <div className="card mb-5">
                <div className="card-body">
                  <h5 className="card-title mb-4">سحابة الوسوم</h5>
                  <div className="tag-cloud text-center p-3">
                    {sortedTags.map(tag => (
                      <Link 
                        key={tag._id} 
                        to={`/tags/${tag.slug}`} 
                        className={`tag-item d-inline-block m-2 text-decoration-none ${getTagSizeClass(tag)}`}
                      >
                        <span className="badge bg-light text-dark p-2 rounded-pill">
                          <i className="fas fa-tag me-1 text-primary"></i>
                          {tag.name}
                          <span className="badge bg-primary ms-1 rounded-pill">
                            {tag.counts.fatwas + tag.counts.articles}
                          </span>
                        </span>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="row">
                {sortedTags.map(tag => (
                  <div key={tag._id} className="col-md-6 col-lg-4 mb-4">
                    <div className="card h-100 border-light shadow-sm">
                      <div className="card-body">
                        <h3 className="card-title mb-3">
                          <Link to={`/tags/${tag.slug}`} className="text-decoration-none">
                            <i className="fas fa-tag me-2 text-primary"></i>
                            {tag.name}
                          </Link>
                        </h3>
                        <p className="card-text text-muted">
                          {tag.description}
                        </p>
                      </div>
                      <div className="card-footer bg-white border-top-0">
                        <div className="d-flex justify-content-between align-items-center">
                          <div>
                            <span className="badge bg-primary me-2">
                              <i className="fas fa-scroll me-1"></i>
                              {tag.counts.fatwas} فتوى
                            </span>
                            <span className="badge bg-success">
                              <i className="fas fa-newspaper me-1"></i>
                              {tag.counts.articles} مقال
                            </span>
                          </div>
                          <Link to={`/tags/${tag.slug}`} className="btn btn-sm btn-outline-primary">
                            تصفح المحتوى
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default TagsList;

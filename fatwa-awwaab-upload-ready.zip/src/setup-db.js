const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

// Create database directory if it doesn't exist
const dbDir = path.join(__dirname, '..', 'db');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

// Connect to SQLite database
const db = new sqlite3.Database(path.join(dbDir, 'fatwa_db.sqlite'));

// Read SQL file
const sqlFile = path.join(__dirname, '..', 'migrations', '0001_initial.sql');
const sql = fs.readFileSync(sqlFile, 'utf8');

// Execute SQL statements
db.serialize(() => {
  // Enable foreign keys
  db.run('PRAGMA foreign_keys = ON');
  
  // Split SQL file into individual statements and execute them
  const statements = sql.split(';').filter(stmt => stmt.trim());
  
  statements.forEach(statement => {
    if (statement.trim()) {
      db.run(statement, err => {
        if (err) {
          console.error('Error executing SQL statement:', err);
          console.error('Statement:', statement);
        }
      });
    }
  });
  
  console.log('Database setup completed successfully!');
});

// Close the database connection
db.close(err => {
  if (err) {
    console.error('Error closing database:', err);
  } else {
    console.log('Database connection closed.');
  }
});

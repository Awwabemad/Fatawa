// This is a simplified version for deployment
// We're removing dynamic routes to avoid TypeScript errors

export default function FatwaPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">الفتاوى الإسلامية</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Fatwa Card 1 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                عبادات
              </span>
              <span className="text-gray-500 text-sm">2025-03-15</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              حكم صيام الست من شوال
            </h3>
            <p className="text-gray-600 mb-4">
              السؤال: ما حكم صيام الست من شوال؟ وهل يجب أن تكون متتابعة؟
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة الفتوى كاملة
            </a>
          </div>
        </div>

        {/* Fatwa Card 2 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                معاملات
              </span>
              <span className="text-gray-500 text-sm">2025-03-10</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              زكاة الأسهم والصناديق الاستثمارية
            </h3>
            <p className="text-gray-600 mb-4">
              السؤال: كيف تخرج زكاة الأسهم والصناديق الاستثمارية؟
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة الفتوى كاملة
            </a>
          </div>
        </div>

        {/* Fatwa Card 3 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                معاملات
              </span>
              <span className="text-gray-500 text-sm">2025-03-05</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              حكم استخدام وسائل التواصل الاجتماعي
            </h3>
            <p className="text-gray-600 mb-4">
              السؤال: ما حكم استخدام وسائل التواصل الاجتماعي؟ وما هي الضوابط الشرعية لذلك؟
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة الفتوى كاملة
            </a>
          </div>
        </div>

        {/* Fatwa Card 4 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                معاملات
              </span>
              <span className="text-gray-500 text-sm">2025-03-01</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              حكم التأمين الصحي
            </h3>
            <p className="text-gray-600 mb-4">
              السؤال: ما حكم التأمين الصحي؟ وهل هناك فرق بين التأمين التجاري والتعاوني؟
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة الفتوى كاملة
            </a>
          </div>
        </div>

        {/* Fatwa Card 5 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                أسرة
              </span>
              <span className="text-gray-500 text-sm">2025-02-25</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              حكم الطلاق الشفهي
            </h3>
            <p className="text-gray-600 mb-4">
              السؤال: هل يقع الطلاق بمجرد التلفظ به؟ وما هي شروط وقوع الطلاق؟
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة الفتوى كاملة
            </a>
          </div>
        </div>

        {/* Fatwa Card 6 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                عقيدة
              </span>
              <span className="text-gray-500 text-sm">2025-02-20</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              حكم الاحتفال بالمولد النبوي
            </h3>
            <p className="text-gray-600 mb-4">
              السؤال: ما حكم الاحتفال بالمولد النبوي؟ وهل هو من البدع أم من السنن؟
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة الفتوى كاملة
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

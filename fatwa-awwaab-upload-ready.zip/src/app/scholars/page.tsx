import Link from 'next/link';

// Types
interface ScholarProps {
  id: number;
  name: string;
  title: string;
  bio: string;
  image?: string;
  fatwaCount: number;
  articleCount: number;
}

// Scholar Card Component
const ScholarCard = ({ scholar }: { scholar: ScholarProps }) => {
  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
      <div className="h-48 bg-gray-200">
        {/* Placeholder for scholar image */}
        <div className="w-full h-full flex items-center justify-center bg-green-100 text-green-800">
          صورة الشيخ
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold mb-1">
          <Link href={`/scholars/${scholar.id}`} className="hover:text-green-700">
            {scholar.name}
          </Link>
        </h3>
        <p className="text-gray-600 mb-4">{scholar.title}</p>
        <p className="text-gray-700 mb-4 line-clamp-3">{scholar.bio}</p>
        <div className="flex justify-between items-center">
          <div className="flex space-x-4 space-x-reverse">
            <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
              {scholar.fatwaCount} فتوى
            </span>
            <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
              {scholar.articleCount} مقال
            </span>
          </div>
          <Link 
            href={`/scholars/${scholar.id}`}
            className="text-green-700 hover:text-green-900 font-medium"
          >
            عرض الملف الشخصي
          </Link>
        </div>
      </div>
    </div>
  );
};

export default function Scholars() {
  // Mock data for scholars
  const scholars: ScholarProps[] = [
    {
      id: 1,
      name: 'الشيخ عبد العزيز',
      title: 'أستاذ الفقه وأصوله',
      bio: 'عالم متخصص في الفقه وأصوله، له العديد من المؤلفات والبحوث في مجال الفقه الإسلامي، ويشغل منصب عضو هيئة كبار العلماء.',
      fatwaCount: 120,
      articleCount: 45,
    },
    {
      id: 2,
      name: 'الشيخ محمد',
      title: 'أستاذ العقيدة والمذاهب المعاصرة',
      bio: 'متخصص في العقيدة الإسلامية والمذاهب المعاصرة، له إسهامات في الرد على الشبهات المثارة حول الإسلام، ويشارك في العديد من المؤتمرات الدولية.',
      fatwaCount: 95,
      articleCount: 37,
    },
    {
      id: 3,
      name: 'الشيخ أحمد',
      title: 'أستاذ الحديث وعلومه',
      bio: 'متخصص في علوم الحديث والسنة النبوية، له مؤلفات في تخريج الأحاديث ودراسة الأسانيد، ويشرف على عدد من طلاب الدراسات العليا.',
      fatwaCount: 85,
      articleCount: 29,
    },
    {
      id: 4,
      name: 'الشيخ عبد الله',
      title: 'أستاذ الفقه المقارن',
      bio: 'متخصص في الفقه المقارن والدراسات الفقهية المعاصرة، له بحوث في النوازل الفقهية والقضايا المستجدة، ويشارك في المجامع الفقهية.',
      fatwaCount: 110,
      articleCount: 42,
    },
    {
      id: 5,
      name: 'الشيخ عبد الرحمن',
      title: 'أستاذ التفسير وعلوم القرآن',
      bio: 'متخصص في التفسير وعلوم القرآن، له مؤلفات في التفسير الموضوعي والإعجاز القرآني، ويشرف على كرسي التفسير في جامعة مرموقة.',
      fatwaCount: 75,
      articleCount: 50,
    },
    {
      id: 6,
      name: 'الشيخ خالد',
      title: 'أستاذ الدعوة والثقافة الإسلامية',
      bio: 'متخصص في الدعوة والثقافة الإسلامية، له إسهامات في مجال الحوار الحضاري والتواصل مع الآخر، ويشارك في برامج إعلامية متنوعة.',
      fatwaCount: 65,
      articleCount: 55,
    },
  ];

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="bg-green-700 text-white rounded-lg p-8">
        <h1 className="text-3xl font-bold mb-4">العلماء والمشايخ</h1>
        <p className="text-lg">تعرف على العلماء والمشايخ المشاركين في الموقع وتصفح فتاواهم ومقالاتهم</p>
      </div>

      {/* Search Section */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="relative">
          <input
            type="text"
            placeholder="ابحث عن عالم أو شيخ..."
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <button className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-green-700 text-white px-4 py-2 rounded-md hover:bg-green-800">
            بحث
          </button>
        </div>
      </div>

      {/* Scholars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {scholars.map((scholar) => (
          <ScholarCard key={scholar.id} scholar={scholar} />
        ))}
      </div>
    </div>
  );
}

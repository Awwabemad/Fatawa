"use client";

import Link from 'next/link';
import { useState } from 'react';

export default function FatwasList() {
  // Mock data for fatwas
  const [fatwas, setFatwas] = useState([
    { id: 1, title: 'حكم صيام الست من شوال', category: 'عبادات', scholar: 'الشيخ عبد العزيز', date: '2025-03-15', status: 'published' },
    { id: 2, title: 'زكاة الأسهم والصناديق الاستثمارية', category: 'معاملات', scholar: 'الشيخ محمد', date: '2025-03-10', status: 'published' },
    { id: 3, title: 'حكم استخدام وسائل التواصل الاجتماعي', category: 'معاملات', scholar: 'الشيخ أحمد', date: '2025-03-05', status: 'draft' },
    { id: 4, title: 'حكم التأمين الصحي', category: 'معاملات', scholar: 'الشيخ عبد الله', date: '2025-03-01', status: 'published' },
    { id: 5, title: 'حكم الطلاق الشفهي', category: 'أسرة', scholar: 'الشيخ محمد', date: '2025-02-25', status: 'published' },
    { id: 6, title: 'حكم الاحتفال بالمولد النبوي', category: 'عقيدة', scholar: 'الشيخ أحمد', date: '2025-02-20', status: 'draft' },
  ]);

  // State for search and filter
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');

  // Handle delete fatwa
  const handleDelete = (id: number) => {
    if (window.confirm('هل أنت متأكد من حذف هذه الفتوى؟')) {
      setFatwas(fatwas.filter(fatwa => fatwa.id !== id));
    }
  };

  // Filter fatwas based on search term and filters
  const filteredFatwas = fatwas.filter(fatwa => {
    const matchesSearch = fatwa.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          fatwa.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          fatwa.scholar.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || fatwa.status === statusFilter;
    const matchesCategory = categoryFilter === 'all' || fatwa.category === categoryFilter;
    
    return matchesSearch && matchesStatus && matchesCategory;
  });

  // Get unique categories for filter
  const categories = ['all', ...new Set(fatwas.map(fatwa => fatwa.category))];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">إدارة الفتاوى</h1>
        <Link 
          href="/admin/fatwas/new" 
          className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
        >
          إضافة فتوى جديدة
        </Link>
      </div>

      {/* Search and Filter */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Search */}
          <div>
            <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
              بحث
            </label>
            <input
              type="text"
              id="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ابحث عن عنوان، تصنيف، أو مفتي..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
            />
          </div>

          {/* Status Filter */}
          <div>
            <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
              الحالة
            </label>
            <select
              id="status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
            >
              <option value="all">الكل</option>
              <option value="published">منشور</option>
              <option value="draft">مسودة</option>
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
              التصنيف
            </label>
            <select
              id="category"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
            >
              {categories.map((category, index) => (
                <option key={index} value={category}>
                  {category === 'all' ? 'الكل' : category}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Fatwas Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  العنوان
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  التصنيف
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  المفتي
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  التاريخ
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الحالة
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الإجراءات
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredFatwas.length > 0 ? (
                filteredFatwas.map((fatwa) => (
                  <tr key={fatwa.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{fatwa.title}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{fatwa.category}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{fatwa.scholar}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{fatwa.date}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        fatwa.status === 'published' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {fatwa.status === 'published' ? 'منشور' : 'مسودة'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <Link href={`/admin/fatwas/${fatwa.id}/edit`} className="text-indigo-600 hover:text-indigo-900 ml-4">
                        تعديل
                      </Link>
                      <button 
                        onClick={() => handleDelete(fatwa.id)} 
                        className="text-red-600 hover:text-red-900"
                      >
                        حذف
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="px-6 py-4 text-center text-gray-500">
                    لا توجد فتاوى مطابقة للبحث
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

"use client";

import Link from 'next/link';
import FatwaForm from '@/components/admin/FatwaForm';

export default function NewFatwa() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">إضافة فتوى جديدة</h1>
        <Link 
          href="/admin/fatwas" 
          className="bg-gray-100 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-200"
        >
          العودة إلى قائمة الفتاوى
        </Link>
      </div>
      
      <FatwaForm fatwa={null} />
    </div>
  );
}

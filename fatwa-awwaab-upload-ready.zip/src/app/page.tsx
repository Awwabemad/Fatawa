// This is a simplified version for deployment
// We're removing dynamic routes to avoid TypeScript errors

export default function HomePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-green-50 rounded-lg shadow-md p-8 mb-8">
        <h1 className="text-4xl font-bold text-green-800 mb-4">موقع الفتاوى والمقالات الإسلامية</h1>
        <p className="text-xl text-gray-700 mb-6">
          مرحباً بكم في موقع الفتاوى والمقالات الإسلامية، المنصة الشاملة للفتاوى الشرعية والمقالات الإسلامية المتنوعة
        </p>
        <div className="flex flex-wrap gap-4">
          <a href="/fatwas" className="bg-green-600 text-white px-6 py-3 rounded-md hover:bg-green-700 transition-colors">
            تصفح الفتاوى
          </a>
          <a href="/articles" className="bg-white text-green-700 border border-green-600 px-6 py-3 rounded-md hover:bg-green-50 transition-colors">
            تصفح المقالات
          </a>
        </div>
      </div>

      {/* Featured Fatwas */}
      <div className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">أحدث الفتاوى</h2>
          <a href="/fatwas" className="text-green-700 hover:text-green-900 font-medium">
            عرض جميع الفتاوى
          </a>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Fatwa Card 1 */}
          <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
            <div className="p-6">
              <div className="flex justify-between items-start mb-3">
                <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                  عبادات
                </span>
                <span className="text-gray-500 text-sm">2025-03-15</span>
              </div>
              <h3 className="text-xl font-bold mb-2">
                حكم صيام الست من شوال
              </h3>
              <p className="text-gray-600 mb-4">
                السؤال: ما حكم صيام الست من شوال؟ وهل يجب أن تكون متتابعة؟
              </p>
              <a href="#" className="text-green-700 hover:text-green-900 font-medium">
                قراءة الفتوى كاملة
              </a>
            </div>
          </div>

          {/* Fatwa Card 2 */}
          <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
            <div className="p-6">
              <div className="flex justify-between items-start mb-3">
                <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                  معاملات
                </span>
                <span className="text-gray-500 text-sm">2025-03-10</span>
              </div>
              <h3 className="text-xl font-bold mb-2">
                زكاة الأسهم والصناديق الاستثمارية
              </h3>
              <p className="text-gray-600 mb-4">
                السؤال: كيف تخرج زكاة الأسهم والصناديق الاستثمارية؟
              </p>
              <a href="#" className="text-green-700 hover:text-green-900 font-medium">
                قراءة الفتوى كاملة
              </a>
            </div>
          </div>

          {/* Fatwa Card 3 */}
          <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
            <div className="p-6">
              <div className="flex justify-between items-start mb-3">
                <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                  معاملات
                </span>
                <span className="text-gray-500 text-sm">2025-03-05</span>
              </div>
              <h3 className="text-xl font-bold mb-2">
                حكم استخدام وسائل التواصل الاجتماعي
              </h3>
              <p className="text-gray-600 mb-4">
                السؤال: ما حكم استخدام وسائل التواصل الاجتماعي؟ وما هي الضوابط الشرعية لذلك؟
              </p>
              <a href="#" className="text-green-700 hover:text-green-900 font-medium">
                قراءة الفتوى كاملة
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Articles */}
      <div>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">أحدث المقالات</h2>
          <a href="/articles" className="text-green-700 hover:text-green-900 font-medium">
            عرض جميع المقالات
          </a>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Article Card 1 */}
          <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-48 bg-green-100 flex items-center justify-center text-green-800 font-bold">
              صورة المقال
            </div>
            <div className="p-6">
              <div className="flex justify-between items-start mb-3">
                <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                  عبادات
                </span>
                <span className="text-gray-500 text-sm">2025-03-20</span>
              </div>
              <h3 className="text-xl font-bold mb-2">
                فضل العشر الأوائل من ذي الحجة
              </h3>
              <p className="text-gray-600 mb-4">
                تعرف على فضل العشر الأوائل من ذي الحجة وأهم الأعمال المستحبة فيها
              </p>
              <a href="#" className="text-green-700 hover:text-green-900 font-medium">
                قراءة المقال كاملاً
              </a>
            </div>
          </div>

          {/* Article Card 2 */}
          <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-48 bg-green-100 flex items-center justify-center text-green-800 font-bold">
              صورة المقال
            </div>
            <div className="p-6">
              <div className="flex justify-between items-start mb-3">
                <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                  أخلاق
                </span>
                <span className="text-gray-500 text-sm">2025-03-18</span>
              </div>
              <h3 className="text-xl font-bold mb-2">
                أثر الصدق في حياة المسلم
              </h3>
              <p className="text-gray-600 mb-4">
                الصدق من أعظم الصفات التي يجب أن يتحلى بها المسلم، وله آثار عظيمة في حياته
              </p>
              <a href="#" className="text-green-700 hover:text-green-900 font-medium">
                قراءة المقال كاملاً
              </a>
            </div>
          </div>

          {/* Article Card 3 */}
          <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-48 bg-green-100 flex items-center justify-center text-green-800 font-bold">
              صورة المقال
            </div>
            <div className="p-6">
              <div className="flex justify-between items-start mb-3">
                <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                  عقيدة
                </span>
                <span className="text-gray-500 text-sm">2025-03-12</span>
              </div>
              <h3 className="text-xl font-bold mb-2">
                الوسطية في الإسلام
              </h3>
              <p className="text-gray-600 mb-4">
                الوسطية منهج إسلامي أصيل، وهي سمة من سمات هذا الدين العظيم
              </p>
              <a href="#" className="text-green-700 hover:text-green-900 font-medium">
                قراءة المقال كاملاً
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

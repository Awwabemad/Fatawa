// This is a simplified version for deployment
// We're using a static page to avoid TypeScript errors with dynamic routes

export default function ArticlesPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">المقالات الإسلامية</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Article Card 1 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="h-48 bg-green-100 flex items-center justify-center text-green-800 font-bold">
            صورة المقال
          </div>
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                عبادات
              </span>
              <span className="text-gray-500 text-sm">2025-03-20</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              فضل العشر الأوائل من ذي الحجة
            </h3>
            <p className="text-gray-600 mb-4">
              تعرف على فضل العشر الأوائل من ذي الحجة وأهم الأعمال المستحبة فيها
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة المقال كاملاً
            </a>
          </div>
        </div>

        {/* Article Card 2 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="h-48 bg-green-100 flex items-center justify-center text-green-800 font-bold">
            صورة المقال
          </div>
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                أخلاق
              </span>
              <span className="text-gray-500 text-sm">2025-03-18</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              أثر الصدق في حياة المسلم
            </h3>
            <p className="text-gray-600 mb-4">
              الصدق من أعظم الصفات التي يجب أن يتحلى بها المسلم، وله آثار عظيمة في حياته
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة المقال كاملاً
            </a>
          </div>
        </div>

        {/* Article Card 3 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="h-48 bg-green-100 flex items-center justify-center text-green-800 font-bold">
            صورة المقال
          </div>
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                عقيدة
              </span>
              <span className="text-gray-500 text-sm">2025-03-12</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              الوسطية في الإسلام
            </h3>
            <p className="text-gray-600 mb-4">
              الوسطية منهج إسلامي أصيل، وهي سمة من سمات هذا الدين العظيم
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة المقال كاملاً
            </a>
          </div>
        </div>

        {/* Article Card 4 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="h-48 bg-green-100 flex items-center justify-center text-green-800 font-bold">
            صورة المقال
          </div>
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                معاملات
              </span>
              <span className="text-gray-500 text-sm">2025-03-05</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              أحكام الزكاة المعاصرة
            </h3>
            <p className="text-gray-600 mb-4">
              دراسة في أحكام الزكاة المعاصرة وتطبيقاتها في الحياة المعاصرة
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة المقال كاملاً
            </a>
          </div>
        </div>

        {/* Article Card 5 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="h-48 bg-green-100 flex items-center justify-center text-green-800 font-bold">
            صورة المقال
          </div>
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                أسرة
              </span>
              <span className="text-gray-500 text-sm">2025-02-28</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              تربية الأبناء في ظل التكنولوجيا الحديثة
            </h3>
            <p className="text-gray-600 mb-4">
              نصائح وتوجيهات في تربية الأبناء في عصر التكنولوجيا والإنترنت
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة المقال كاملاً
            </a>
          </div>
        </div>

        {/* Article Card 6 */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
          <div className="h-48 bg-green-100 flex items-center justify-center text-green-800 font-bold">
            صورة المقال
          </div>
          <div className="p-6">
            <div className="flex justify-between items-start mb-3">
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                فقه
              </span>
              <span className="text-gray-500 text-sm">2025-02-25</span>
            </div>
            <h3 className="text-xl font-bold mb-2">
              مقاصد الشريعة وأثرها في الفتوى
            </h3>
            <p className="text-gray-600 mb-4">
              دراسة في مقاصد الشريعة الإسلامية وأثرها في الفتوى المعاصرة
            </p>
            <a href="#" className="text-green-700 hover:text-green-900 font-medium">
              قراءة المقال كاملاً
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

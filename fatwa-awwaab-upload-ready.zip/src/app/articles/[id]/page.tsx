import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'تفاصيل المقال - موقع الفتاوى والمقالات الإسلامية',
  description: 'صفحة تفاصيل المقال في موقع الفتاوى والمقالات الإسلامية',
};

// This function is required for static exports with dynamic routes
export function generateStaticParams() {
  // For static export, we'll pre-render these specific IDs
  return [
    { id: '1' },
    { id: '2' },
    { id: '3' },
    { id: '4' },
    { id: '5' },
  ];
}

export default function ArticleDetail({ params }: { params: { id: string } }) {
  const { id } = params;
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">مقال رقم {id}</h1>
      <p className="text-gray-600">
        هذه صفحة تفاصيل المقال. في الإصدار النهائي، سيتم عرض محتوى المقال هنا بناءً على المعرف {id}.
      </p>
      
      <div className="mt-8">
        <a href="/articles" className="text-green-700 hover:text-green-900 font-medium">
          العودة إلى قائمة المقالات
        </a>
      </div>
    </div>
  );
}

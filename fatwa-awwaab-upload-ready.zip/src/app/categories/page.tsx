import Link from 'next/link';

// Types
interface CategoryProps {
  id: number;
  name: string;
  description: string;
  count: number;
}

// Category Card Component
const CategoryCard = ({ category }: { category: CategoryProps }) => {
  return (
    <Link 
      href={`/categories/${category.id}`}
      className="bg-white shadow-md rounded-lg p-6 hover:shadow-lg transition-shadow"
    >
      <h3 className="text-xl font-bold mb-2 text-green-800">{category.name}</h3>
      <p className="text-gray-600 mb-4">{category.description}</p>
      <div className="flex justify-between items-center">
        <span className="bg-green-100 text-green-800 text-sm font-medium px-3 py-1 rounded-full">
          {category.count} فتوى ومقال
        </span>
        <svg className="h-5 w-5 text-green-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
      </div>
    </Link>
  );
};

export default function Categories() {
  // Mock data for categories
  const categories: CategoryProps[] = [
    {
      id: 1,
      name: 'عقيدة',
      description: 'فتاوى ومقالات متعلقة بالعقيدة الإسلامية وأصول الإيمان',
      count: 45,
    },
    {
      id: 2,
      name: 'عبادات',
      description: 'فتاوى ومقالات متعلقة بالصلاة والصيام والزكاة والحج وغيرها من العبادات',
      count: 78,
    },
    {
      id: 3,
      name: 'معاملات',
      description: 'فتاوى ومقالات متعلقة بالبيع والشراء والمعاملات المالية المعاصرة',
      count: 63,
    },
    {
      id: 4,
      name: 'أسرة',
      description: 'فتاوى ومقالات متعلقة بالزواج والطلاق والعلاقات الأسرية وتربية الأبناء',
      count: 52,
    },
    {
      id: 5,
      name: 'أخلاق',
      description: 'فتاوى ومقالات متعلقة بالأخلاق والسلوك والآداب الإسلامية',
      count: 37,
    },
    {
      id: 6,
      name: 'فقه',
      description: 'فتاوى ومقالات متعلقة بالفقه الإسلامي وأحكامه المختلفة',
      count: 29,
    },
  ];

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="bg-green-700 text-white rounded-lg p-8">
        <h1 className="text-3xl font-bold mb-4">تصنيفات الفتاوى والمقالات</h1>
        <p className="text-lg">تصفح الفتاوى والمقالات الإسلامية حسب التصنيفات المختلفة</p>
      </div>

      {/* Search Section */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="relative">
          <input
            type="text"
            placeholder="ابحث عن تصنيف..."
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <button className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-green-700 text-white px-4 py-2 rounded-md hover:bg-green-800">
            بحث
          </button>
        </div>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((category) => (
          <CategoryCard key={category.id} category={category} />
        ))}
      </div>
    </div>
  );
}

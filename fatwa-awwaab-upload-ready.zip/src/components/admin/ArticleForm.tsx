"use client";

import { useState } from 'react';
import Link from 'next/link';

interface Article {
  title?: string;
  summary?: string;
  content?: string;
  author_id?: string;
  category_id?: string;
  featured_image?: string;
  status?: string;
}

export default function ArticleForm({ article = null }: { article: Article | null }) {
  // State for form data
  const [formData, setFormData] = useState({
    title: article?.title || '',
    summary: article?.summary || '',
    content: article?.content || '',
    author_id: article?.author_id || '',
    category_id: article?.category_id || '',
    featured_image: article?.featured_image || '',
    status: article?.status || 'published',
  });

  // State for form submission
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [submitSuccess, setSubmitSuccess] = useState('');

  // Mock data for categories and authors (scholars)
  const categories = [
    { id: 1, name: 'عقيدة' },
    { id: 2, name: 'عبادات' },
    { id: 3, name: 'معاملات' },
    { id: 4, name: 'أسرة' },
    { id: 5, name: 'أخلاق' },
  ];

  const authors = [
    { id: 1, name: 'الشيخ عبد العزيز' },
    { id: 2, name: 'الشيخ محمد' },
    { id: 3, name: 'الشيخ أحمد' },
    { id: 4, name: 'الشيخ عبد الله' },
  ];

  // Handle form input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitError('');
    setSubmitSuccess('');

    try {
      // Validate form data
      if (!formData.title || !formData.summary || !formData.content || !formData.author_id || !formData.category_id) {
        throw new Error('جميع الحقول مطلوبة');
      }

      // In a real application, this would be an API call
      // For now, we'll just simulate a successful submission
      await new Promise(resolve => setTimeout(resolve, 1000));

      setSubmitSuccess(article ? 'تم تحديث المقال بنجاح' : 'تم إضافة المقال بنجاح');
    } catch (error) {
      setSubmitError((error as Error).message || 'حدث خطأ أثناء حفظ المقال');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white shadow-md rounded-lg p-6">
      {/* Form header */}
      <div className="mb-6">
        <h2 className="text-xl font-bold">{article ? 'تعديل مقال' : 'إضافة مقال جديد'}</h2>
        <p className="text-gray-600">أدخل معلومات المقال في النموذج أدناه</p>
      </div>

      {/* Success message */}
      {submitSuccess && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          <p>{submitSuccess}</p>
        </div>
      )}

      {/* Error message */}
      {submitError && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          <p>{submitError}</p>
        </div>
      )}

      {/* Title field */}
      <div className="mb-4">
        <label htmlFor="title" className="block text-gray-700 font-bold mb-2">
          عنوان المقال
        </label>
        <input
          type="text"
          id="title"
          name="title"
          value={formData.title}
          onChange={handleChange}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          placeholder="أدخل عنوان المقال"
          required
        />
      </div>

      {/* Category field */}
      <div className="mb-4">
        <label htmlFor="category_id" className="block text-gray-700 font-bold mb-2">
          التصنيف
        </label>
        <select
          id="category_id"
          name="category_id"
          value={formData.category_id}
          onChange={handleChange}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          required
        >
          <option value="">اختر التصنيف</option>
          {categories.map(category => (
            <option key={category.id} value={category.id}>
              {category.name}
            </option>
          ))}
        </select>
      </div>

      {/* Author field */}
      <div className="mb-4">
        <label htmlFor="author_id" className="block text-gray-700 font-bold mb-2">
          الكاتب
        </label>
        <select
          id="author_id"
          name="author_id"
          value={formData.author_id}
          onChange={handleChange}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          required
        >
          <option value="">اختر الكاتب</option>
          {authors.map(author => (
            <option key={author.id} value={author.id}>
              {author.name}
            </option>
          ))}
        </select>
      </div>

      {/* Featured Image field */}
      <div className="mb-4">
        <label htmlFor="featured_image" className="block text-gray-700 font-bold mb-2">
          صورة المقال
        </label>
        <input
          type="text"
          id="featured_image"
          name="featured_image"
          value={formData.featured_image}
          onChange={handleChange}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          placeholder="أدخل رابط صورة المقال"
        />
      </div>

      {/* Summary field */}
      <div className="mb-4">
        <label htmlFor="summary" className="block text-gray-700 font-bold mb-2">
          ملخص المقال
        </label>
        <textarea
          id="summary"
          name="summary"
          value={formData.summary}
          onChange={handleChange}
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          placeholder="أدخل ملخص المقال"
          required
        ></textarea>
      </div>

      {/* Content field */}
      <div className="mb-4">
        <label htmlFor="content" className="block text-gray-700 font-bold mb-2">
          محتوى المقال
        </label>
        <textarea
          id="content"
          name="content"
          value={formData.content}
          onChange={handleChange}
          rows={12}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          placeholder="أدخل محتوى المقال"
          required
        ></textarea>
      </div>

      {/* Status field */}
      <div className="mb-6">
        <label htmlFor="status" className="block text-gray-700 font-bold mb-2">
          الحالة
        </label>
        <select
          id="status"
          name="status"
          value={formData.status}
          onChange={handleChange}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          required
        >
          <option value="published">منشور</option>
          <option value="draft">مسودة</option>
        </select>
      </div>

      {/* Form actions */}
      <div className="flex items-center justify-end space-x-4 space-x-reverse">
        <Link
          href="/admin/articles"
          className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
        >
          إلغاء
        </Link>
        <button
          type="submit"
          className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'جاري الحفظ...' : article ? 'تحديث المقال' : 'إضافة المقال'}
        </button>
      </div>
    </form>
  );
}

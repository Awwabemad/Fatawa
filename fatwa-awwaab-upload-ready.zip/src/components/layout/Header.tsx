import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-green-800 text-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold">
              موقع الفتاوى والمقالات
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-white focus:outline-none"
            >
              <svg
                className="h-6 w-6"
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                {isMenuOpen ? (
                  <path d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="hover:text-green-200 px-3">
              الرئيسية
            </Link>
            <Link href="/fatwas" className="hover:text-green-200 px-3">
              الفتاوى
            </Link>
            <Link href="/articles" className="hover:text-green-200 px-3">
              المقالات
            </Link>
            <Link href="/categories" className="hover:text-green-200 px-3">
              التصنيفات
            </Link>
            <Link href="/scholars" className="hover:text-green-200 px-3">
              العلماء
            </Link>
            <Link href="/about" className="hover:text-green-200 px-3">
              عن الموقع
            </Link>
            <Link href="/contact" className="hover:text-green-200 px-3">
              اتصل بنا
            </Link>
          </nav>

          <div className="hidden md:flex items-center">
            <Link 
              href="/admin" 
              className="bg-white text-green-800 px-4 py-2 rounded-md hover:bg-green-100"
            >
              لوحة التحكم
            </Link>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pt-4 border-t border-green-700">
            <div className="flex flex-col space-y-3">
              <Link 
                href="/" 
                className="hover:bg-green-700 px-3 py-2 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                الرئيسية
              </Link>
              <Link 
                href="/fatwas" 
                className="hover:bg-green-700 px-3 py-2 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                الفتاوى
              </Link>
              <Link 
                href="/articles" 
                className="hover:bg-green-700 px-3 py-2 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                المقالات
              </Link>
              <Link 
                href="/categories" 
                className="hover:bg-green-700 px-3 py-2 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                التصنيفات
              </Link>
              <Link 
                href="/scholars" 
                className="hover:bg-green-700 px-3 py-2 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                العلماء
              </Link>
              <Link 
                href="/about" 
                className="hover:bg-green-700 px-3 py-2 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                عن الموقع
              </Link>
              <Link 
                href="/contact" 
                className="hover:bg-green-700 px-3 py-2 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                اتصل بنا
              </Link>
              <Link 
                href="/admin" 
                className="bg-white text-green-800 px-3 py-2 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                لوحة التحكم
              </Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}

import { Env } from './types';

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;
    
    // API routes
    if (path.startsWith('/api/')) {
      return handleApiRequest(request, env);
    }
    
    // Return 404 for any other routes
    return new Response('Not Found', { status: 404 });
  }
};

async function handleApiRequest(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;
  
  // Fatwas API
  if (path.startsWith('/api/fatwas')) {
    return handleFatwaRequest(request, env);
  }
  
  // Articles API
  if (path.startsWith('/api/articles')) {
    return handleArticleRequest(request, env);
  }
  
  // Categories API
  if (path.startsWith('/api/categories')) {
    return handleCategoryRequest(request, env);
  }
  
  // Scholars API
  if (path.startsWith('/api/scholars')) {
    return handleScholarRequest(request, env);
  }
  
  // Search API
  if (path.startsWith('/api/search')) {
    return handleSearchRequest(request, env);
  }
  
  // Auth API
  if (path.startsWith('/api/auth')) {
    return handleAuthRequest(request, env);
  }
  
  // Return 404 for any other API routes
  return new Response('API Not Found', { status: 404 });
}

async function handleFatwaRequest(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;
  
  // GET /api/fatwas - List all fatwas
  if (path === '/api/fatwas' && method === 'GET') {
    const { searchParams } = url;
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const category = searchParams.get('category');
    const scholar = searchParams.get('scholar');
    
    let query = 'SELECT f.*, c.name as category_name, s.name as scholar_name FROM fatwas f LEFT JOIN categories c ON f.category_id = c.id LEFT JOIN scholars s ON f.scholar_id = s.id WHERE f.status = "published"';
    const params: any[] = [];
    
    if (category) {
      query += ' AND c.name = ?';
      params.push(category);
    }
    
    if (scholar) {
      query += ' AND s.name = ?';
      params.push(scholar);
    }
    
    query += ' ORDER BY f.created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, (page - 1) * limit);
    
    try {
      const fatwas = await env.DB.prepare(query).bind(...params).all();
      const countResult = await env.DB.prepare('SELECT COUNT(*) as count FROM fatwas WHERE status = "published"').first();
      const total = countResult?.count || 0;
      
      return new Response(JSON.stringify({
        success: true,
        data: fatwas.results,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit)
        }
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to fetch fatwas'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }
  
  // GET /api/fatwas/:id - Get a specific fatwa
  if (path.match(/^\/api\/fatwas\/\d+$/) && method === 'GET') {
    const id = path.split('/').pop();
    
    try {
      const fatwa = await env.DB.prepare('SELECT f.*, c.name as category_name, s.name as scholar_name FROM fatwas f LEFT JOIN categories c ON f.category_id = c.id LEFT JOIN scholars s ON f.scholar_id = s.id WHERE f.id = ? AND f.status = "published"').bind(id).first();
      
      if (!fatwa) {
        return new Response(JSON.stringify({
          success: false,
          error: 'Fatwa not found'
        }), {
          status: 404,
          headers: { 'Content-Type': 'application/json' }
        });
      }
      
      // Increment views
      await env.DB.prepare('UPDATE fatwas SET views = views + 1 WHERE id = ?').bind(id).run();
      
      // Get related fatwas
      const relatedFatwas = await env.DB.prepare('SELECT f.id, f.title FROM fatwas f WHERE f.category_id = ? AND f.id != ? AND f.status = "published" ORDER BY f.created_at DESC LIMIT 3').bind(fatwa.category_id, id).all();
      
      return new Response(JSON.stringify({
        success: true,
        data: fatwa,
        related: relatedFatwas.results
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to fetch fatwa'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }
  
  // POST /api/fatwas - Create a new fatwa (requires authentication)
  if (path === '/api/fatwas' && method === 'POST') {
    // Check authentication
    const user = await authenticateUser(request, env);
    if (!user) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Unauthorized'
      }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    try {
      const { title, question, answer, scholar_id, category_id } = await request.json();
      
      // Validate required fields
      if (!title || !question || !answer || !scholar_id || !category_id) {
        return new Response(JSON.stringify({
          success: false,
          error: 'Missing required fields'
        }), {
          status: 400,
          headers: { 'Content-Type': 'application/json' }
        });
      }
      
      const result = await env.DB.prepare('INSERT INTO fatwas (title, question, answer, scholar_id, category_id, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)').bind(title, question, answer, scholar_id, category_id, 'published').run();
      
      return new Response(JSON.stringify({
        success: true,
        data: {
          id: result.meta.last_row_id
        },
        message: 'Fatwa created successfully'
      }), {
        status: 201,
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to create fatwa'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }
  
  // PUT /api/fatwas/:id - Update a fatwa (requires authentication)
  if (path.match(/^\/api\/fatwas\/\d+$/) && method === 'PUT') {
    // Check authentication
    const user = await authenticateUser(request, env);
    if (!user) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Unauthorized'
      }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    const id = path.split('/').pop();
    
    try {
      const { title, question, answer, scholar_id, category_id, status } = await request.json();
      
      // Validate required fields
      if (!title || !question || !answer || !scholar_id || !category_id) {
        return new Response(JSON.stringify({
          success: false,
          error: 'Missing required fields'
        }), {
          status: 400,
          headers: { 'Content-Type': 'application/json' }
        });
      }
      
      await env.DB.prepare('UPDATE fatwas SET title = ?, question = ?, answer = ?, scholar_id = ?, category_id = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').bind(title, question, answer, scholar_id, category_id, status || 'published', id).run();
      
      return new Response(JSON.stringify({
        success: true,
        message: 'Fatwa updated successfully'
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to update fatwa'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }
  
  // DELETE /api/fatwas/:id - Delete a fatwa (requires authentication)
  if (path.match(/^\/api\/fatwas\/\d+$/) && method === 'DELETE') {
    // Check authentication
    const user = await authenticateUser(request, env);
    if (!user) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Unauthorized'
      }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    const id = path.split('/').pop();
    
    try {
      await env.DB.prepare('DELETE FROM fatwas WHERE id = ?').bind(id).run();
      
      return new Response(JSON.stringify({
        success: true,
        message: 'Fatwa deleted successfully'
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to delete fatwa'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }
  
  return new Response('Method not allowed', { status: 405 });
}

async function handleArticleRequest(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;
  
  // GET /api/articles - List all articles
  if (path === '/api/articles' && method === 'GET') {
    const { searchParams } = url;
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const category = searchParams.get('category');
    const author = searchParams.get('author');
    
    let query = 'SELECT a.*, c.name as category_name, s.name as author_name FROM articles a LEFT JOIN categories c ON a.category_id = c.id LEFT JOIN scholars s ON a.author_id = s.id WHERE a.status = "published"';
    const params: any[] = [];
    
    if (category) {
      query += ' AND c.name = ?';
      params.push(category);
    }
    
    if (author) {
      query += ' AND s.name = ?';
      params.push(author);
    }
    
    query += ' ORDER BY a.created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, (page - 1) * limit);
    
    try {
      const articles = await env.DB.prepare(query).bind(...params).all();
      const countResult = await env.DB.prepare('SELECT COUNT(*) as count FROM articles WHERE status = "published"').first();
      const total = countResult?.count || 0;
      
      return new Response(JSON.stringify({
        success: true,
        data: articles.results,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit)
        }
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to fetch articles'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }
  
  // Similar implementations for GET /api/articles/:id, POST, PUT, DELETE
  
  return new Response('Method not allowed', { status: 405 });
}

async function handleCategoryRequest(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;
  
  // GET /api/categories - List all categories
  if (path === '/api/categories' && method === 'GET') {
    try {
      const categories = await env.DB.prepare('SELECT * FROM categories ORDER BY name').all();
      
      return new Response(JSON.stringify({
        success: true,
        data: categories.results
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to fetch categories'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }
  
  // Similar implementations for GET /api/categories/:id, POST, PUT, DELETE
  
  return new Response('Method not allowed', { status: 405 });
}

async function handleScholarRequest(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;
  
  // GET /api/scholars - List all scholars
  if (path === '/api/scholars' && method === 'GET') {
    try {
      const scholars = await env.DB.prepare('SELECT * FROM scholars ORDER BY name').all();
      
      return new Response(JSON.stringify({
        success: true,
        data: scholars.results
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to fetch scholars'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }
  
  // Similar implementations for GET /api/scholars/:id, POST, PUT, DELETE
  
  return new Response('Method not allowed', { status: 405 });
}

async function handleSearchRequest(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const query = url.searchParams.get('q');
  
  if (!query) {
    return new Response(JSON.stringify({
      success: false,
      error: 'Search query is required'
    }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }
  
  try {
    // Search in fatwas
    const fatwas = await env.DB.prepare(`
      SELECT f.id, f.title, f.question, 'fatwa' as type, c.name as category, s.name as author
      FROM fatwas f
      LEFT JOIN categories c ON f.category_id = c.id
      LEFT JOIN scholars s ON f.scholar_id = s.id
      WHERE f.status = "published" AND (f.title LIKE ? OR f.question LIKE ? OR f.answer LIKE ?)
      LIMIT 10
    `).bind(`%${query}%`, `%${query}%`, `%${query}%`).all();
    
    // Search in articles
    const articles = await env.DB.prepare(`
      SELECT a.id, a.title, a.summary, 'article' as type, c.name as category, s.name as author
      FROM articles a
      LEFT JOIN categories c ON a.category_id = c.id
      LEFT JOIN scholars s ON a.author_id = s.id
      WHERE a.status = "published" AND (a.title LIKE ? OR a.summary LIKE ? OR a.content LIKE ?)
      LIMIT 10
    `).bind(`%${query}%`, `%${query}%`, `%${query}%`).all();
    
    return new Response(JSON.stringify({
      success: true,
      data: {
        fatwas: fatwas.results,
        articles: articles.results
      }
    }), {
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    return new Response(JSON.stringify({
      success: false,
      error: 'Failed to perform search'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function handleAuthRequest(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;
  
  // POST /api/auth/login - Login
  if (path === '/api/auth/login' && method === 'POST') {
    try {
      const { username, password } = await request.json();
      
      if (!username || !password) {
        return new Response(JSON.stringify({
          success: false,
          error: 'Username and password are required'
        }), {
          status: 400,
          headers: { 'Content-Type': 'application/json' }
        });
      }
      
      // In a real application, you would hash the password and compare with the stored hash
      const user = await env.DB.prepare('SELECT * FROM users WHERE username = ?').bind(username).first();
      
      if (!user || user.password_hash !== password) {
        return new Response(JSON.stringify({
          success: false,
          error: 'Invalid username or password'
        }), {
          status: 401,
          headers: { 'Content-Type': 'application/json' }
        });
      }
      
      // Update last login
      await env.DB.prepare('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?').bind(user.id).run();
      
      // In a real application, you would generate a JWT token
      const token = 'dummy-token';
      
      return new Response(JSON.stringify({
        success: true,
        data: {
          user: {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role
          },
          token
        }
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Failed to login'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }
  
  // GET /api/auth/me - Get current user
  if (path === '/api/auth/me' && method === 'GET') {
    const user = await authenticateUser(request, env);
    
    if (!user) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Unauthorized'
      }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    return new Response(JSON.stringify({
      success: true,
      data: {
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role
        }
      }
    }), {
      headers: { 'Content-Type': 'application/json' }
    });
  }
  
  // POST /api/auth/logout - Logout
  if (path === '/api/auth/logout' && method === 'POST') {
    // In a real application, you would invalidate the token
    
    return new Response(JSON.stringify({
      success: true,
      message: 'Logged out successfully'
    }), {
      headers: { 'Content-Type': 'application/json' }
    });
  }
  
  return new Response('Method not allowed', { status: 405 });
}

async function authenticateUser(request: Request, env: Env): Promise<any> {
  // In a real application, you would verify the JWT token
  const authHeader = request.headers.get('Authorization');
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  
  const token = authHeader.split(' ')[1];
  
  // For demo purposes, we'll just check if the token is 'dummy-token'
  if (token !== 'dummy-token') {
    return null;
  }
  
  // Return a dummy user
  return {
    id: 1,
    username: 'admin',
    email: 'admin@example.com',
    role: 'admin'
  };
}

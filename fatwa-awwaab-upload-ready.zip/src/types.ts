export interface Env {
  DB: any; // Using 'any' type to avoid D1Database dependency issues
}

export interface Fatwa {
  id: number;
  title: string;
  question: string;
  answer: string;
  category_id: number;
  scholar_id: number;
  date_created: string;
  date_updated: string;
  status: string;
}

export interface Article {
  id: number;
  title: string;
  summary: string;
  content: string;
  category_id: number;
  author_id: number;
  featured_image: string;
  date_created: string;
  date_updated: string;
  status: string;
}

export interface Category {
  id: number;
  name: string;
  description: string;
  parent_id: number | null;
}

export interface Scholar {
  id: number;
  name: string;
  bio: string;
  image: string;
}

export interface User {
  id: number;
  username: string;
  email: string;
  password_hash: string;
  role: string;
  date_created: string;
  last_login: string;
}

export interface Tag {
  id: number;
  name: string;
}

export interface FatwaTag {
  fatwa_id: number;
  tag_id: number;
}

export interface ArticleTag {
  article_id: number;
  tag_id: number;
}

-- Initial database schema for Fatwa and Articles website

-- Create categories table
CREATE TABLE categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create authors/scholars table
CREATE TABLE scholars (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  title TEXT,
  bio TEXT,
  image_url TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create fatwas table
CREATE TABLE fatwas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  scholar_id INTEGER,
  category_id INTEGER,
  status TEXT DEFAULT 'published',
  views INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (scholar_id) REFERENCES scholars(id),
  FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Create articles table
CREATE TABLE articles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  summary TEXT,
  author_id INTEGER,
  category_id INTEGER,
  featured_image TEXT,
  status TEXT DEFAULT 'published',
  views INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (author_id) REFERENCES scholars(id),
  FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Create tags table
CREATE TABLE tags (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create fatwa_tags junction table
CREATE TABLE fatwa_tags (
  fatwa_id INTEGER,
  tag_id INTEGER,
  PRIMARY KEY (fatwa_id, tag_id),
  FOREIGN KEY (fatwa_id) REFERENCES fatwas(id) ON DELETE CASCADE,
  FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
);

-- Create article_tags junction table
CREATE TABLE article_tags (
  article_id INTEGER,
  tag_id INTEGER,
  PRIMARY KEY (article_id, tag_id),
  FOREIGN KEY (article_id) REFERENCES articles(id) ON DELETE CASCADE,
  FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
);

-- Create users table for admin access
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  email TEXT UNIQUE,
  role TEXT DEFAULT 'editor',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_login TIMESTAMP
);

-- Insert some initial categories
INSERT INTO categories (name, description) VALUES 
('عقيدة', 'فتاوى متعلقة بالعقيدة الإسلامية'),
('عبادات', 'فتاوى متعلقة بالصلاة والصيام والزكاة والحج'),
('معاملات', 'فتاوى متعلقة بالبيع والشراء والمعاملات المالية'),
('أسرة', 'فتاوى متعلقة بالزواج والطلاق والعلاقات الأسرية'),
('أخلاق', 'فتاوى متعلقة بالأخلاق والسلوك');

-- Insert a default admin user (password: admin123)
INSERT INTO users (username, password_hash, email, role) VALUES 
('admin', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'admin@example.com', 'admin');
